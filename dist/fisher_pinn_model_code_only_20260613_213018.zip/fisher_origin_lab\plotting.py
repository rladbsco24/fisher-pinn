from __future__ import annotations

from pathlib import Path
from typing import Iterable

from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.ticker import MaxNLocator
import matplotlib.pyplot as plt
import numpy as np
import torch

from .config import DomainConfig, ObservationConfig, SeedConfig
from .losses import front_indicator_weights, front_speed_kinematics, pde_residual_terms
from .metrics import centroid_from_field, relative_l2
from .models import OriginPINN
from .simulate import ObservationData, TruthData, truth_field_at


TOKENS = {
    "surface": "#FCFCFD",
    "panel": "#FFFFFF",
    "ink": "#1F2430",
    "muted": "#6F768A",
    "grid": "#E6E8F0",
    "axis": "#D7DBE7",
}

COLORS = {
    "blue": "#5477C4",
    "blue_light": "#CEDFFE",
    "gold": "#B8A037",
    "orange": "#CC6F47",
    "olive": "#71B436",
    "pink": "#BD569B",
    "rose": "#D95F5F",
    "teal": "#2A9D8F",
    "neutral": "#7A828F",
}

# Research-style scientific colormap roles. Scalar state fields use a
# perceptually uniform color-vision-deficiency-friendly map; error magnitudes
# use a high-contrast sequential map; signed deviations use a zero-centered
# diverging map.
FIELD_CMAP = "cividis"
ERROR_CMAP = "inferno"
SIGNED_ERROR_CMAP = "RdBu_r"
RESIDUAL_CMAP = "inferno"
FRONT_CMAP = "cividis"
WEIGHT_CMAP = "YlOrBr"


def _apply_chart_theme() -> None:
    plt.rcParams.update(
        {
            "figure.facecolor": TOKENS["surface"],
            "axes.facecolor": TOKENS["panel"],
            "axes.edgecolor": TOKENS["axis"],
            "axes.labelcolor": TOKENS["ink"],
            "xtick.color": TOKENS["muted"],
            "ytick.color": TOKENS["muted"],
            "grid.color": TOKENS["grid"],
            "grid.linewidth": 0.8,
            "font.family": "DejaVu Sans",
            "savefig.facecolor": TOKENS["surface"],
            "savefig.edgecolor": "none",
        }
    )


def _style_axis(ax: plt.Axes, *, grid: bool = False) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(TOKENS["axis"])
    ax.spines["bottom"].set_color(TOKENS["axis"])
    ax.tick_params(labelsize=8)
    if grid:
        ax.grid(True, alpha=0.7)
    else:
        ax.grid(False)


def _write_title(fig: plt.Figure, title: str, subtitle: str | None = None, *, top: float = 0.88) -> None:
    fig.subplots_adjust(top=top)
    fig.text(0.01, 0.985, title, ha="left", va="top", fontsize=13, fontweight="semibold", color=TOKENS["ink"])
    if subtitle:
        fig.text(0.01, 0.952, subtitle, ha="left", va="top", fontsize=9, color=TOKENS["muted"])


def _add_colorbar(
    fig: plt.Figure,
    image,
    ax: plt.Axes,
    *,
    fraction: float = 0.046,
    pad: float = 0.035,
    extend: str = "neither",
):
    cbar = fig.colorbar(image, ax=ax, fraction=fraction, pad=pad, extend=extend)
    cbar.ax.tick_params(labelsize=8, pad=3, colors=TOKENS["muted"])
    cbar.ax.yaxis.set_ticks_position("right")
    cbar.ax.yaxis.set_label_position("right")
    cbar.ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    cbar.outline.set_edgecolor(TOKENS["axis"])
    cbar.outline.set_linewidth(0.8)
    return cbar


def _save_figure(fig: plt.Figure, path: Path, *, dpi: int = 150) -> None:
    fig.savefig(path, dpi=dpi, bbox_inches="tight", pad_inches=0.10)


def _imshow(
    fig: plt.Figure,
    ax: plt.Axes,
    field: np.ndarray,
    domain: DomainConfig,
    *,
    title: str,
    cmap: str,
    vmin: float | None = None,
    vmax: float | None = None,
    colorbar: bool = False,
) -> None:
    im = ax.imshow(
        field.T,
        origin="lower",
        extent=[0, domain.box, 0, domain.box],
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        interpolation="nearest",
    )
    ax.set_title(title, fontsize=9, color=TOKENS["ink"])
    ax.set_xticks([])
    ax.set_yticks([])
    if colorbar:
        _add_colorbar(fig, im, ax)


def _as_history_arrays(history: list[dict[str, float]], key: str) -> tuple[np.ndarray, np.ndarray]:
    rows = [row for row in history if key in row and np.isfinite(row[key])]
    if not rows:
        return np.array([]), np.array([])
    return np.array([row["epoch"] for row in rows], dtype=np.float64), np.array([row[key] for row in rows], dtype=np.float64)


def predict_field(model: OriginPINN, time: float, n: int, device: torch.device) -> tuple[np.ndarray, np.ndarray]:
    xs = np.linspace(0.0, model.domain.box, n)
    x, y = np.meshgrid(xs, xs, indexing="ij")
    xy = torch.tensor(np.stack([x.ravel(), y.ravel()], axis=1), dtype=torch.float32, device=device)
    t = torch.full((n * n, 1), float(time), dtype=torch.float32, device=device)
    with torch.no_grad():
        field = model(xy, t).detach().cpu().numpy().reshape(n, n)
    return xs, field


def residual_front_maps(
    model: OriginPINN,
    time: float,
    n: int,
    device: torch.device,
    *,
    front_alpha: float = 0.0,
    front_gradient: float = 0.0,
    front_speed_min_grad: float = 1.0e-2,
    use_curvature_correction: bool = False,
    curvature_correction_weight: float = 0.05,
) -> dict[str, np.ndarray]:
    xs = np.linspace(0.0, model.domain.box, n)
    x, y = np.meshgrid(xs, xs, indexing="ij")
    xy = torch.tensor(np.stack([x.ravel(), y.ravel()], axis=1), dtype=torch.float32, device=device)
    t = torch.full((n * n, 1), float(time), dtype=torch.float32, device=device)
    residual, u, u_xy, _, _ = pde_residual_terms(model, xy, t)
    grad_norm = torch.linalg.norm(u_xy, dim=-1, keepdim=True)
    weights = front_indicator_weights(u, u_xy, front_alpha, front_gradient)
    kin = front_speed_kinematics(
        model,
        xy,
        t,
        use_curvature_correction=use_curvature_correction,
        curvature_correction_weight=curvature_correction_weight,
        compute_curvature=True,
    )
    front_band = (
        (u.detach() > 0.05)
        & (u.detach() < 0.95)
        & (grad_norm.detach() > front_speed_min_grad)
    ).cpu().numpy().reshape(n, n)
    normal_speed = kin["observed_normal_speed"].detach().cpu().numpy().reshape(n, n)
    target_speed = kin["target_normal_speed"].detach().cpu().numpy().reshape(n, n)
    speed_error = np.abs(kin["speed_error"].detach().cpu().numpy().reshape(n, n))
    speed_residual = kin["signed_residual"].detach().cpu().numpy().reshape(n, n)
    mean_curvature = kin["mean_curvature"].detach().cpu().numpy().reshape(n, n)
    curvature_correction = kin["curvature_speed_correction"].detach().cpu().numpy().reshape(n, n)
    return {
        "u": u.detach().cpu().numpy().reshape(n, n),
        "residual_abs": residual.detach().abs().cpu().numpy().reshape(n, n),
        "front_indicator": (u.detach() * (1.0 - u.detach())).cpu().numpy().reshape(n, n),
        "grad_norm": grad_norm.detach().cpu().numpy().reshape(n, n),
        "front_weight": weights.detach().cpu().numpy().reshape(n, n),
        "normal_speed": np.where(front_band, normal_speed, np.nan),
        "target_speed": np.where(front_band, target_speed, np.nan),
        "front_speed_error": np.where(front_band, speed_error, np.nan),
        "speed_residual": np.where(front_band, speed_residual, np.nan),
        "mean_curvature": np.where(front_band, mean_curvature, np.nan),
        "curvature_correction": np.where(front_band, curvature_correction, np.nan),
    }


def save_reconstruction_figure(
    path: Path,
    truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    observations: ObservationConfig,
    seed: SeedConfig,
    device: torch.device,
    ensemble_centers: list[tuple[float, float]] | None = None,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    times = [0.0, observations.start_time * 0.5, observations.start_time, domain.t_end]
    n = 96
    fig, axes = plt.subplots(3, len(times), figsize=(4.0 * len(times), 9.5), constrained_layout=False)
    fig.subplots_adjust(left=0.045, right=0.94, bottom=0.045, top=0.88, hspace=0.26, wspace=0.22)
    true_center = (seed.center_x, seed.center_y)
    xs_late, late = truth_field_at(truth, domain.t_end, n=n)
    centroid = centroid_from_field(xs_late, late)
    est_center = tuple(model.source.center().detach().cpu().numpy().tolist())
    show_source_estimate = bool(getattr(model, "use_source_envelope", False))

    for col, time_value in enumerate(times):
        _, true_field = truth_field_at(truth, time_value, n=n)
        _, pred = predict_field(model, time_value, n=n, device=device)
        err = np.abs(pred - true_field)
        for row, field, label, cmap, vmin, vmax in [
            (0, true_field, "truth", FIELD_CMAP, 0.0, 1.0),
            (1, pred, "pinn", FIELD_CMAP, 0.0, 1.0),
            (2, err, "absolute error", ERROR_CMAP, 0.0, None),
        ]:
            ax = axes[row, col]
            _imshow(
                fig,
                ax,
                field,
                domain,
                title=f"{label} t={time_value:.2f}",
                cmap=cmap,
                vmin=vmin,
                vmax=vmax,
                colorbar=(col == len(times) - 1),
            )
            ax.plot(*true_center, marker="*", color="cyan", markersize=11, markeredgecolor="white", markeredgewidth=0.8)
            if row == 1 and show_source_estimate:
                ax.plot(*est_center, marker="+", color="lime", markersize=12, markeredgewidth=2.5)
                ax.plot(*centroid, marker="x", color="red", markersize=10, markeredgewidth=2.5)
                if ensemble_centers:
                    arr = np.array(ensemble_centers)
                    ax.scatter(arr[:, 0], arr[:, 1], s=18, c="white", edgecolors="black", linewidths=0.5)

    subtitle = "Rows show truth, prediction, and absolute error. Cyan marks the synthetic source."
    if show_source_estimate:
        subtitle += " Green is the trainable source estimate; red is the late weighted centroid."
    _write_title(fig, "Fisher-KPP field reconstruction", subtitle, top=0.88)
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_spacetime_error_figure(
    path: Path,
    truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    device: torch.device,
    *,
    n: int = 96,
    max_times: int = 14,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    if len(truth.times) <= max_times:
        times = truth.times
    else:
        idx = np.linspace(0, len(truth.times) - 1, max_times).astype(int)
        times = truth.times[idx]

    rel_l2 = []
    truth_mass = []
    pred_mass = []
    truth_front = []
    pred_front = []
    truth_level_005 = []
    pred_level_005 = []
    truth_level_010 = []
    pred_level_010 = []
    for time_value in times:
        _, true_field = truth_field_at(truth, float(time_value), n=n)
        _, pred = predict_field(model, float(time_value), n=n, device=device)
        rel_l2.append(relative_l2(pred, true_field))
        truth_mass.append(float(true_field.mean()))
        pred_mass.append(float(pred.mean()))
        truth_front.append(float(np.mean((true_field > 0.1) & (true_field < 0.9))))
        pred_front.append(float(np.mean((pred > 0.1) & (pred < 0.9))))
        truth_level_005.append(float(np.mean(true_field > 0.05)))
        pred_level_005.append(float(np.mean(pred > 0.05)))
        truth_level_010.append(float(np.mean(true_field > 0.10)))
        pred_level_010.append(float(np.mean(pred > 0.10)))

    fig, axes = plt.subplots(2, 2, figsize=(12.8, 7.2), constrained_layout=False)
    fig.subplots_adjust(left=0.065, right=0.985, bottom=0.08, top=0.84, hspace=0.34, wspace=0.24)
    axes[0, 0].plot(times, rel_l2, marker="o", color=COLORS["blue"], linewidth=1.4)
    axes[0, 0].set_ylabel("Relative L2")
    axes[0, 0].set_xlabel("Time")
    axes[0, 0].set_title("field error", fontsize=9)

    axes[0, 1].plot(times, truth_mass, marker="o", color=COLORS["neutral"], linewidth=1.2, label="truth")
    axes[0, 1].plot(times, pred_mass, marker="o", color=COLORS["olive"], linewidth=1.2, label="pinn")
    axes[0, 1].set_ylabel("Mean density")
    axes[0, 1].set_xlabel("Time")
    axes[0, 1].set_title("mass trajectory", fontsize=9)
    axes[0, 1].legend(frameon=False, fontsize=8)

    axes[1, 0].plot(times, truth_front, marker="o", color=COLORS["neutral"], linewidth=1.2, label="truth")
    axes[1, 0].plot(times, pred_front, marker="o", color=COLORS["orange"], linewidth=1.2, label="pinn")
    axes[1, 0].set_ylabel("Area fraction")
    axes[1, 0].set_xlabel("Time")
    axes[1, 0].set_title("active-front band", fontsize=9)
    axes[1, 0].legend(frameon=False, fontsize=8)

    axes[1, 1].plot(times, truth_level_005, marker="o", color=COLORS["neutral"], linewidth=1.2, label="truth u>0.05")
    axes[1, 1].plot(times, pred_level_005, marker="o", color=COLORS["teal"], linewidth=1.2, linestyle="--", label="pinn u>0.05")
    axes[1, 1].plot(times, truth_level_010, marker="s", color=COLORS["blue"], linewidth=1.2, label="truth u>0.10")
    axes[1, 1].plot(times, pred_level_010, marker="s", color=COLORS["pink"], linewidth=1.2, linestyle="--", label="pinn u>0.10")
    axes[1, 1].set_ylabel("Area fraction")
    axes[1, 1].set_xlabel("Time")
    axes[1, 1].set_title("low-level front area", fontsize=9)
    axes[1, 1].legend(frameon=False, fontsize=7, ncol=2)

    for ax in axes.ravel():
        _style_axis(ax, grid=True)
    _write_title(
        fig,
        "Space-time prediction diagnostics",
        "Trend views summarize field error, mass, active front, and low-level moving-front area.",
        top=0.84,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_training_diagnostics_figure(
    path: Path,
    history: list[dict[str, float]],
    *,
    true_diffusion: float | None = None,
    true_reaction: float | None = None,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 2, figsize=(12.0, 7.6), constrained_layout=False)
    fig.subplots_adjust(left=0.065, right=0.985, bottom=0.08, top=0.84, hspace=0.34, wspace=0.24)

    for key, color in [
        ("total", COLORS["blue"]),
        ("data", COLORS["olive"]),
        ("observation_support", COLORS["rose"]),
        ("validation_data", COLORS["blue_light"]),
        ("pde", COLORS["orange"]),
        ("ic", COLORS["gold"]),
        ("bc", COLORS["neutral"]),
        ("mass", COLORS["teal"]),
        ("mass_floor", COLORS["olive"]),
        ("expected_front_pde", COLORS["gold"]),
        ("leading_edge", COLORS["pink"]),
        ("leading_edge_area", COLORS["teal"]),
        ("front_support_tversky", COLORS["olive"]),
        ("front_contrast", COLORS["rose"]),
        ("front_profile", COLORS["blue"]),
        ("level_set", COLORS["gold"]),
        ("intrinsic_phase_gradient_alignment", COLORS["teal"]),
        ("intrinsic_phase_monotonicity", COLORS["rose"]),
        ("front_speed", COLORS["blue_light"]),
        ("front_grad", COLORS["pink"]),
        ("grad", COLORS["neutral"]),
        ("physics_anchor", COLORS["neutral"]),
        ("coefficient_field", COLORS["teal"]),
    ]:
        epochs, values = _as_history_arrays(history, key)
        if len(values) and np.nanmax(values) > 0.0:
            axes[0, 0].plot(epochs, values, marker="o", linewidth=1.2, label=key, color=color)
    axes[0, 0].set_yscale("log")
    axes[0, 0].set_title("loss components", fontsize=9)
    axes[0, 0].set_xlabel("Epoch")
    axes[0, 0].set_ylabel("Loss")
    axes[0, 0].legend(frameon=False, fontsize=7, ncol=2)

    for key, color, true_value in [
        ("diffusion", COLORS["blue"], true_diffusion),
        ("reaction", COLORS["orange"], true_reaction),
        ("diffusion_field_mean", COLORS["teal"], true_diffusion),
        ("reaction_field_mean", COLORS["pink"], true_reaction),
    ]:
        epochs, values = _as_history_arrays(history, key)
        if len(values):
            axes[0, 1].plot(epochs, values, marker="o", linewidth=1.2, label=key, color=color)
            if true_value is not None:
                axes[0, 1].axhline(true_value, color=color, linestyle=":", linewidth=1.0)
    axes[0, 1].set_title("learned PDE coefficients", fontsize=9)
    axes[0, 1].set_xlabel("Epoch")
    axes[0, 1].set_ylabel("Value")
    axes[0, 1].legend(frameon=False, fontsize=8)

    for key, color in [
        ("front_weight_mean", COLORS["blue"]),
        ("residual_exponent", COLORS["gold"]),
        ("sparse", COLORS["orange"]),
        ("diffusion_field_std", COLORS["teal"]),
        ("reaction_field_std", COLORS["pink"]),
        ("coefficient_log_abs_mean", COLORS["neutral"]),
        ("time_window_high", COLORS["pink"]),
        ("origin_error", COLORS["olive"]),
    ]:
        epochs, values = _as_history_arrays(history, key)
        if len(values) and np.nanmax(values) > 0.0:
            axes[1, 0].plot(epochs, values, marker="o", linewidth=1.2, label=key, color=color)
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_title("auxiliary diagnostics", fontsize=9)
    axes[1, 0].set_xlabel("Epoch")
    axes[1, 0].set_ylabel("Value")
    axes[1, 0].legend(frameon=False, fontsize=8)

    adaptive_keys = [
        ("aw_data", COLORS["olive"]),
        ("aw_pde", COLORS["orange"]),
        ("aw_ic", COLORS["gold"]),
        ("aw_bc", COLORS["neutral"]),
        ("aw_mass", COLORS["teal"]),
        ("aw_mass_floor", COLORS["olive"]),
        ("aw_expected_front_pde", COLORS["gold"]),
        ("aw_leading_edge", COLORS["pink"]),
        ("aw_front_support_tversky", COLORS["olive"]),
        ("aw_front_contrast", COLORS["rose"]),
        ("aw_front_profile", COLORS["blue"]),
        ("aw_level_set", COLORS["gold"]),
        ("aw_intrinsic_phase_gradient_alignment", COLORS["teal"]),
        ("aw_intrinsic_phase_monotonicity", COLORS["rose"]),
        ("aw_front_speed", COLORS["blue_light"]),
        ("aw_front_grad", COLORS["pink"]),
        ("aw_coefficient_field", COLORS["teal"]),
    ]
    plotted_adaptive = False
    for key, color in adaptive_keys:
        epochs, values = _as_history_arrays(history, key)
        if len(values):
            axes[1, 1].plot(epochs, values, marker="o", linewidth=1.2, label=key.replace("aw_", ""), color=color)
            plotted_adaptive = True
    if plotted_adaptive:
        axes[1, 1].set_title("adaptive loss multipliers", fontsize=9)
        axes[1, 1].set_xlabel("Epoch")
        axes[1, 1].set_ylabel("Multiplier")
        axes[1, 1].legend(frameon=False, fontsize=7, ncol=2)
    else:
        epochs, elapsed = _as_history_arrays(history, "elapsed_sec")
        if len(elapsed):
            axes[1, 1].plot(epochs, elapsed, marker="o", linewidth=1.2, color=COLORS["neutral"])
        axes[1, 1].set_title("runtime accumulation", fontsize=9)
        axes[1, 1].set_xlabel("Epoch")
        axes[1, 1].set_ylabel("Seconds")

    for ax in axes.ravel():
        _style_axis(ax, grid=True)
    _write_title(
        fig,
        "Training diagnostics",
        "Loss including known IC, moving-front speed, mass balance, adaptive multipliers, and learned coefficients.",
        top=0.84,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_residual_front_diagnostics_figure(
    path: Path,
    truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    device: torch.device,
    *,
    time_value: float,
    front_alpha: float = 0.0,
    front_gradient: float = 0.0,
    use_curvature_correction: bool = False,
    curvature_correction_weight: float = 0.05,
    n: int = 64,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    _, true_field = truth_field_at(truth, time_value, n=n)
    maps = residual_front_maps(
        model,
        time_value,
        n=n,
        device=device,
        front_alpha=front_alpha,
        front_gradient=front_gradient,
        use_curvature_correction=use_curvature_correction,
        curvature_correction_weight=curvature_correction_weight,
    )
    abs_error = np.abs(maps["u"] - true_field)
    residual_log = np.log10(maps["residual_abs"] + 1.0e-8)

    panels: list[tuple[str, np.ndarray, str, float | None, float | None]] = [
        ("truth", true_field, FIELD_CMAP, 0.0, 1.0),
        ("prediction", maps["u"], FIELD_CMAP, 0.0, 1.0),
        ("absolute error", abs_error, ERROR_CMAP, 0.0, None),
        ("log10 |PDE residual|", residual_log, RESIDUAL_CMAP, None, None),
        ("u(1-u) front indicator", maps["front_indicator"], FRONT_CMAP, 0.0, 0.25),
        ("front/adaptive weight", maps["front_weight"], WEIGHT_CMAP, None, None),
        ("normal front speed", maps["normal_speed"], SIGNED_ERROR_CMAP, None, None),
        ("front-speed error", maps["front_speed_error"], ERROR_CMAP, 0.0, None),
        ("mean curvature kappa", maps["mean_curvature"], SIGNED_ERROR_CMAP, None, None),
        ("signed speed residual", maps["speed_residual"], SIGNED_ERROR_CMAP, None, None),
    ]
    fig, axes = plt.subplots(3, 4, figsize=(15.2, 10.8), constrained_layout=False)
    fig.subplots_adjust(left=0.04, right=0.94, bottom=0.07, top=0.84, hspace=0.36, wspace=0.24)
    flat_axes = axes.ravel()
    for ax, (title, field, cmap, vmin, vmax) in zip(flat_axes, panels):
        _imshow(fig, ax, field, domain, title=title, cmap=cmap, vmin=vmin, vmax=vmax, colorbar=True)
    hist_specs = [
        ("front-band kappa distribution", maps["mean_curvature"], COLORS["teal"]),
        ("front-band speed residual distribution", maps["speed_residual"], COLORS["rose"]),
    ]
    for ax, (title, field, color) in zip(flat_axes[len(panels) :], hist_specs):
        values = np.asarray(field, dtype=np.float64)
        values = values[np.isfinite(values)]
        if values.size:
            ax.hist(values, bins=min(32, max(8, int(np.sqrt(values.size)))), color=color, alpha=0.82)
            ax.axvline(float(np.mean(values)), color=TOKENS["ink"], linewidth=1.1, linestyle="--")
            ax.set_xlabel("Value")
            ax.set_ylabel("Count")
        else:
            ax.text(0.5, 0.5, "no active front samples", ha="center", va="center", transform=ax.transAxes)
        ax.set_title(title, fontsize=8)
        _style_axis(ax, grid=True)

    _write_title(
        fig,
        "Residual and active-front diagnostics",
        (
            f"Maps at t={time_value:.2f}; curvature correction "
            f"{'on' if use_curvature_correction else 'off'} with weight={curvature_correction_weight:.3g}."
        ),
        top=0.84,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def _initial_phase_target_numpy(
    domain: DomainConfig,
    seed: SeedConfig,
    x: np.ndarray,
    y: np.ndarray,
    *,
    level: float,
    benchmark_kind: str = "gaussian_seed",
    x_left: float = -20.0,
    x_right: float = 20.0,
    x0: float = 0.0,
) -> np.ndarray:
    if benchmark_kind == "ablowitz_zeppetella":
        level_safe = np.clip(float(level), 1.0e-8, 1.0 - 1.0e-8)
        x_level_physical = float(x0) + np.sqrt(6.0) * np.log(level_safe ** -0.5 - 1.0)
        x_level_unit = (x_level_physical - float(x_left)) / (float(x_right) - float(x_left))
        return x / max(float(domain.box), 1.0e-12) - x_level_unit
    amplitude = max(float(seed.amplitude), 1.0e-8)
    level_clamped = min(max(float(level), 1.0e-8), amplitude * (1.0 - 1.0e-7))
    radius = float(seed.sigma) * np.sqrt(max(0.0, -2.0 * np.log(level_clamped / amplitude)))
    dist = np.sqrt((x - float(seed.center_x)) ** 2 + (y - float(seed.center_y)) ** 2)
    return (dist - radius) / max(float(domain.box), 1.0e-12)


def save_initial_phase_contour_diagnostic_figure(
    path: Path,
    model: OriginPINN,
    domain: DomainConfig,
    seed: SeedConfig,
    device: torch.device,
    *,
    level: float = 0.10,
    benchmark_kind: str = "gaussian_seed",
    x_left: float = -20.0,
    x_right: float = 20.0,
    x0: float = 0.0,
    n: int = 96,
) -> None:
    if getattr(model, "front_phase_head", None) is None:
        return
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    xs = np.linspace(0.0, domain.box, n)
    x, y = np.meshgrid(xs, xs, indexing="ij")
    xy = torch.tensor(np.stack([x.reshape(-1), y.reshape(-1)], axis=1), dtype=torch.float32, device=device)
    t0 = torch.zeros(len(xy), 1, dtype=torch.float32, device=device)
    with torch.no_grad():
        u0 = model(xy, t0).detach().cpu().numpy().reshape(n, n)
        psi = model.phase(xy, t0).detach().cpu().numpy().reshape(n, n)
    target = _initial_phase_target_numpy(
        domain,
        seed,
        x,
        y,
        level=level,
        benchmark_kind=benchmark_kind,
        x_left=x_left,
        x_right=x_right,
        x0=x0,
    )
    error = psi - target
    value_lim = max(
        float(np.nanmax(np.abs(psi))),
        float(np.nanmax(np.abs(target))),
        0.1,
    )
    err_lim = float(np.nanmax(np.abs(error)))
    if not np.isfinite(err_lim) or err_lim <= 0.0:
        err_lim = 1.0e-12

    fig, axes = plt.subplots(1, 4, figsize=(16.4, 4.1), constrained_layout=False)
    fig.subplots_adjust(left=0.04, right=0.94, bottom=0.14, top=0.76, wspace=0.30)
    panels = [
        (axes[0], f"initial u, level={level:.2f}", u0, FIELD_CMAP, 0.0, 1.0),
        (axes[1], "learned psi at t=0", psi, SIGNED_ERROR_CMAP, -value_lim, value_lim),
        (axes[2], "target signed distance", target, SIGNED_ERROR_CMAP, -value_lim, value_lim),
        (axes[3], "psi - target", error, SIGNED_ERROR_CMAP, -err_lim, err_lim),
    ]
    for ax, title, field, cmap, vmin, vmax in panels:
        _imshow(fig, ax, field, domain, title=title, cmap=cmap, vmin=vmin, vmax=vmax, colorbar=True)
        try:
            ax.contour(xs, xs, u0.T, levels=[float(level)], colors=[COLORS["teal"]], linewidths=1.4)
            ax.contour(xs, xs, psi.T, levels=[0.0], colors=[COLORS["rose"]], linewidths=1.4, linestyles="--")
            ax.contour(xs, xs, target.T, levels=[0.0], colors=[COLORS["gold"]], linewidths=1.1, linestyles=":")
        except ValueError:
            continue
    axes[0].plot([], [], color=COLORS["teal"], linewidth=1.4, label=f"u={level:.2f}")
    axes[0].plot([], [], color=COLORS["rose"], linewidth=1.4, linestyle="--", label="psi=0")
    axes[0].plot([], [], color=COLORS["gold"], linewidth=1.1, linestyle=":", label="target=0")
    axes[0].legend(frameon=False, fontsize=6, loc="upper right")
    _write_title(
        fig,
        "Initial intrinsic phase contour diagnostic",
        "At t=0, psi=0 should coincide with the selected initial u-level contour; negative psi is the high-u side.",
        top=0.78,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_phase_u_contour_diagnostic_figure(
    path: Path,
    truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    device: torch.device,
    *,
    time_value: float,
    level: float = 0.10,
    n: int = 96,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    xs, true_field = truth_field_at(truth, time_value, n=n)
    _, pred = predict_field(model, time_value, n=n, device=device)
    x, y = np.meshgrid(xs, xs, indexing="ij")
    xy = torch.tensor(np.stack([x.reshape(-1), y.reshape(-1)], axis=1), dtype=torch.float32, device=device)
    t = torch.full((n * n, 1), float(time_value), dtype=torch.float32, device=device)
    with torch.no_grad():
        psi = model.phase(xy, t).detach().cpu().numpy().reshape(n, n)
    psi_lim = max(float(np.nanmax(np.abs(psi))), 0.1)

    fig, axes = plt.subplots(1, 3, figsize=(13.8, 4.4), constrained_layout=False)
    fig.subplots_adjust(left=0.045, right=0.94, bottom=0.14, top=0.78, wspace=0.30)
    _imshow(fig, axes[0], pred, domain, title=f"PINN u with contours, t={time_value:.2f}", cmap=FIELD_CMAP, vmin=0.0, vmax=1.0, colorbar=True)
    _imshow(fig, axes[1], true_field, domain, title="truth/PINN u-threshold", cmap=FIELD_CMAP, vmin=0.0, vmax=1.0, colorbar=True)
    _imshow(fig, axes[2], psi, domain, title="learned psi with u contour", cmap=SIGNED_ERROR_CMAP, vmin=-psi_lim, vmax=psi_lim, colorbar=True)

    for ax in axes:
        try:
            ax.contour(xs, xs, pred.T, levels=[float(level)], colors=[COLORS["teal"]], linewidths=1.5)
        except ValueError:
            pass
        if np.nanmin(psi) <= 0.0 <= np.nanmax(psi):
            try:
                ax.contour(xs, xs, psi.T, levels=[0.0], colors=[COLORS["rose"]], linewidths=1.4, linestyles="--")
            except ValueError:
                pass
    try:
        axes[1].contour(xs, xs, true_field.T, levels=[float(level)], colors=[COLORS["gold"]], linewidths=1.4, linestyles=":")
    except ValueError:
        pass
    axes[0].plot([], [], color=COLORS["teal"], linewidth=1.5, label=f"PINN u={level:.2f}")
    axes[0].plot([], [], color=COLORS["rose"], linewidth=1.4, linestyle="--", label="psi=0")
    axes[0].plot([], [], color=COLORS["gold"], linewidth=1.4, linestyle=":", label=f"truth u={level:.2f}")
    axes[0].legend(frameon=False, fontsize=7, loc="upper right")
    _write_title(
        fig,
        "Phase/u contour diagnostic",
        "The learned psi=0 contour should stabilize, not replace, the physical u-threshold front.",
        top=0.80,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_pinn_rk4_comparison_figure(
    path: Path,
    truth: TruthData,
    rk4_truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    device: torch.device,
    metrics: dict[str, float | None],
    *,
    time_value: float,
    n: int = 96,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    _, true_field = truth_field_at(truth, time_value, n=n)
    _, rk4_field = truth_field_at(rk4_truth, time_value, n=n)
    _, pinn_field = predict_field(model, time_value, n=n, device=device)
    signed_error = pinn_field - true_field
    signed_error_lim = float(np.nanmax(np.abs(signed_error)))
    if not np.isfinite(signed_error_lim) or signed_error_lim <= 0.0:
        signed_error_lim = 1.0e-12
    pinn_error = np.abs(pinn_field - true_field)
    rk4_error = np.abs(rk4_field - true_field)

    fig = plt.figure(figsize=(18.8, 7.6))
    fig.subplots_adjust(left=0.045, right=0.93, bottom=0.07, top=0.84, hspace=0.34, wspace=0.42)
    axes = np.array(
        [
            [
                fig.add_subplot(2, 4, 1),
                fig.add_subplot(2, 4, 2),
                fig.add_subplot(2, 4, 3),
                fig.add_subplot(2, 4, 4),
            ],
            [
                fig.add_subplot(2, 4, 5),
                fig.add_subplot(2, 4, 6),
                fig.add_subplot(2, 4, 7),
                fig.add_subplot(2, 4, 8),
            ],
        ]
    )

    for ax, title, field, cmap, vmin, vmax in [
        (axes[0, 0], "reference", true_field, FIELD_CMAP, 0.0, 1.0),
        (axes[0, 1], "PINN", pinn_field, FIELD_CMAP, 0.0, 1.0),
        (axes[0, 2], "RK4", rk4_field, FIELD_CMAP, 0.0, 1.0),
        (axes[1, 0], "PINN signed error", signed_error, SIGNED_ERROR_CMAP, -signed_error_lim, signed_error_lim),
        (axes[1, 1], "PINN absolute error", pinn_error, ERROR_CMAP, 0.0, None),
        (axes[1, 2], "RK4 absolute error", rk4_error, ERROR_CMAP, 0.0, None),
    ]:
        _imshow(fig, ax, field, domain, title=title, cmap=cmap, vmin=vmin, vmax=vmax, colorbar=True)

    contour_ax = axes[0, 3]
    _imshow(fig, contour_ax, true_field, domain, title="front contours", cmap="Greys", vmin=0.0, vmax=max(0.2, float(true_field.max())), colorbar=False)
    xs = np.linspace(0.0, domain.box, n)
    levels = [0.05, 0.10]
    truth_cs = contour_ax.contour(xs, xs, true_field.T, levels=levels, colors=[COLORS["teal"], COLORS["blue"]], linewidths=1.2)
    pinn_cs = contour_ax.contour(xs, xs, pinn_field.T, levels=levels, colors=[COLORS["teal"], COLORS["blue"]], linewidths=1.2, linestyles="--")
    contour_ax.clabel(truth_cs, fmt=lambda value: f"T {value:.2f}", fontsize=6)
    contour_ax.clabel(pinn_cs, fmt=lambda value: f"P {value:.2f}", fontsize=6)
    contour_ax.plot([], [], color=COLORS["neutral"], linewidth=1.2, label="solid truth")
    contour_ax.plot([], [], color=COLORS["neutral"], linewidth=1.2, linestyle="--", label="dashed PINN")
    contour_ax.legend(frameon=False, fontsize=6, loc="upper right")

    ax = axes[1, 3]
    labels = ["PINN L2", "RK4 L2", "PINN/RK4 L2", "PINN val MSE", "RK4 val MSE"]
    values = [
        metrics.get("pinn_final_relative_l2"),
        metrics.get("rk4_final_relative_l2"),
        metrics.get("pinn_vs_rk4_final_relative_l2"),
        metrics.get("pinn_validation_mse"),
        metrics.get("rk4_validation_mse"),
    ]
    plot_labels = [label for label, value in zip(labels, values) if value is not None and np.isfinite(value)]
    plot_values = [float(value) for value in values if value is not None and np.isfinite(value)]
    colors = [COLORS["blue"], COLORS["orange"], COLORS["gold"], COLORS["blue_light"], "#FFBDA1"][: len(plot_values)]
    if plot_values:
        ax.set_title("accuracy summary", fontsize=9)
        ax.set_axis_off()
        ax.text(0.02, 0.92, "metric", transform=ax.transAxes, fontsize=8, color=TOKENS["muted"], ha="left")
        ax.text(0.98, 0.92, "value", transform=ax.transAxes, fontsize=8, color=TOKENS["muted"], ha="right")
        for idx, (label, value, color) in enumerate(zip(plot_labels, plot_values, colors)):
            y = 0.78 - idx * 0.14
            ax.scatter([0.035], [y], transform=ax.transAxes, s=36, color=color, edgecolor=TOKENS["ink"], linewidth=0.5)
            ax.text(0.09, y, label, transform=ax.transAxes, va="center", ha="left", fontsize=8, color=TOKENS["ink"])
            ax.text(0.98, y, f"{value:.3e}", transform=ax.transAxes, va="center", ha="right", fontsize=8, color=TOKENS["ink"])
    else:
        ax.text(0.5, 0.5, "No comparable metrics", ha="center", va="center", color=TOKENS["muted"])
        ax.set_xticks([])
        ax.set_yticks([])
        _style_axis(ax, grid=True)

    _write_title(
        fig,
        "PINN versus RK4 accuracy comparison",
        f"Both methods solve the same 2D Fisher-KPP problem; maps and metrics are evaluated at t={time_value:.2f}.",
        top=0.84,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def save_pinn_evolution_gif(
    path: Path,
    truth: TruthData,
    model: OriginPINN,
    domain: DomainConfig,
    device: torch.device,
    *,
    n: int = 72,
    max_frames: int = 24,
    fps: int = 5,
    caption: str | None = None,
    warning: str | None = None,
) -> dict[str, object]:
    """Save a compact animated view of truth, PINN prediction, and error over time."""

    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)
    if len(truth.times) <= max_frames:
        times = truth.times
    else:
        idx = np.unique(np.linspace(0, len(truth.times) - 1, max_frames).astype(int))
        times = truth.times[idx]

    frames: list[tuple[float, np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]] = []
    abs_error_vmax = 1.0e-12
    signed_error_lim = 1.0e-12
    frame_relative_l2: list[float] = []
    for time_value in times:
        _, true_field = truth_field_at(truth, float(time_value), n=n)
        _, pred = predict_field(model, float(time_value), n=n, device=device)
        signed = pred - true_field
        err = np.abs(signed)
        rel = relative_l2(pred, true_field)
        abs_error_vmax = max(abs_error_vmax, float(np.nanmax(err)))
        signed_error_lim = max(signed_error_lim, float(np.nanmax(np.abs(signed))))
        frame_relative_l2.append(rel)
        frames.append((float(time_value), true_field, pred, signed, err, rel))

    fig, axes = plt.subplots(1, 4, figsize=(15.8, 4.0), constrained_layout=False)
    fig.subplots_adjust(left=0.035, right=0.925, bottom=0.13, top=0.76, wspace=0.24)
    panels = [
        ("reference truth", frames[0][1], FIELD_CMAP, 0.0, 1.0),
        ("PINN prediction", frames[0][2], FIELD_CMAP, 0.0, 1.0),
        ("signed error", frames[0][3], SIGNED_ERROR_CMAP, -signed_error_lim, signed_error_lim),
        ("absolute error", frames[0][4], ERROR_CMAP, 0.0, abs_error_vmax),
    ]
    images = []
    for ax, (title, field, cmap, vmin, vmax) in zip(axes, panels):
        im = ax.imshow(
            field.T,
            origin="lower",
            extent=[0, domain.box, 0, domain.box],
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
            animated=True,
        )
        ax.set_title(title, fontsize=9, color=TOKENS["ink"])
        ax.set_xticks([])
        ax.set_yticks([])
        images.append(im)
    _add_colorbar(fig, images[2], axes[2])
    _add_colorbar(fig, images[3], axes[3])
    title = fig.text(
        0.01,
        0.965,
        "",
        ha="left",
        va="top",
        fontsize=13,
        fontweight="semibold",
        color=TOKENS["ink"],
    )
    fig.text(
        0.01,
        0.915,
        caption or "Animated PINN reconstruction across the Fisher-KPP time horizon.",
        ha="left",
        va="top",
        fontsize=9,
        color=TOKENS["muted"],
    )
    if warning:
        fig.text(
            0.01,
            0.032,
            warning,
            ha="left",
            va="bottom",
            fontsize=9,
            fontweight="semibold",
            color="#9A3412",
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "#FFF7ED", "edgecolor": "#FDBA74", "linewidth": 0.8},
        )

    def _update(frame_idx: int) -> list[object]:
        time_value, true_field, pred, signed, err, rel = frames[frame_idx]
        images[0].set_data(true_field.T)
        images[1].set_data(pred.T)
        images[2].set_data(signed.T)
        images[3].set_data(err.T)
        title.set_text(f"PINN field evolution t={time_value:.3f} | frame relative L2={rel:.3e}")
        return [*images, title]

    animation = FuncAnimation(fig, _update, frames=len(frames), interval=1000 / max(fps, 1), blit=True)
    animation.save(path, writer=PillowWriter(fps=fps), savefig_kwargs={"pad_inches": 0.12})
    plt.close(fig)
    return {
        "path": str(path),
        "frames": int(len(frames)),
        "grid": int(n),
        "fps": int(fps),
        "max_abs_error": float(abs_error_vmax),
        "max_signed_error_abs": float(signed_error_lim),
        "mean_frame_relative_l2": float(np.mean(frame_relative_l2)),
        "final_frame_relative_l2": float(frame_relative_l2[-1]),
        "warning": warning,
    }


def save_observation_coverage_figure(
    path: Path,
    train_observations: ObservationData,
    validation_observations: ObservationData,
    domain: DomainConfig,
    *,
    max_points: int = 2500,
) -> None:
    _apply_chart_theme()
    path.parent.mkdir(parents=True, exist_ok=True)

    def _sample(obs: ObservationData) -> tuple[np.ndarray, np.ndarray]:
        if len(obs.xyt) <= max_points:
            return obs.xyt, obs.values[:, 0]
        rng = np.random.default_rng(0)
        idx = rng.choice(len(obs.xyt), size=max_points, replace=False)
        return obs.xyt[idx], obs.values[idx, 0]

    train_xyt, train_values = _sample(train_observations)
    val_xyt, val_values = _sample(validation_observations)
    all_times = np.concatenate([train_observations.xyt[:, 2], validation_observations.xyt[:, 2]])

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.9), constrained_layout=False)
    fig.subplots_adjust(left=0.065, right=0.94, bottom=0.13, top=0.78, wspace=0.34)
    sc = axes[0].scatter(
        train_xyt[:, 0],
        train_xyt[:, 1],
        c=train_values,
        s=8,
        cmap=FIELD_CMAP,
        vmin=0.0,
        vmax=1.0,
        alpha=0.75,
        linewidths=0.0,
    )
    axes[0].set_xlim(0.0, domain.box)
    axes[0].set_ylim(0.0, domain.box)
    axes[0].set_aspect("equal")
    axes[0].set_title("train samples", fontsize=9)
    _add_colorbar(fig, sc, axes[0])

    if len(val_xyt):
        axes[1].scatter(val_xyt[:, 0], val_xyt[:, 1], c=val_values, s=10, cmap=FIELD_CMAP, vmin=0.0, vmax=1.0, alpha=0.75, linewidths=0.0)
    axes[1].set_xlim(0.0, domain.box)
    axes[1].set_ylim(0.0, domain.box)
    axes[1].set_aspect("equal")
    axes[1].set_title("validation samples", fontsize=9)

    bins = np.linspace(0.0, domain.t_end, min(12, max(4, len(np.unique(all_times)) + 1)))
    axes[2].hist(train_observations.xyt[:, 2], bins=bins, color=COLORS["blue"], alpha=0.65, label="train")
    if len(validation_observations.xyt):
        axes[2].hist(validation_observations.xyt[:, 2], bins=bins, color=COLORS["orange"], alpha=0.65, label="validation")
    axes[2].set_title("time coverage", fontsize=9)
    axes[2].set_xlabel("Time")
    axes[2].set_ylabel("Observation count")
    axes[2].legend(frameon=False, fontsize=8)

    for ax in axes:
        _style_axis(ax, grid=ax is axes[2])
    _write_title(
        fig,
        "Observation coverage",
        "Spatial samples are colored by normalized infection density; histogram shows train/validation time support.",
        top=0.78,
    )
    _save_figure(fig, path, dpi=150)
    plt.close(fig)


def generated_figure_names() -> list[str]:
    return [
        "observation_coverage.png",
        "reconstruction.png",
        "spacetime_error.png",
        "residual_front_diagnostics.png",
        "initial_phase_contour_diagnostic.png",
        "phase_u_contour_diagnostic.png",
        "pinn_vs_rk4_comparison.png",
        "pinn_evolution.gif",
        "training_diagnostics.png",
    ]


def existing_figures(out_dir: Path) -> Iterable[Path]:
    for name in generated_figure_names():
        path = out_dir / name
        if path.exists():
            yield path

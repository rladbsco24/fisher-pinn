from __future__ import annotations

import math
import signal
import time
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
import torch

from .baselines import (
    BaselineResult,
    differentiable_seed_baseline,
    drift_corrected_observation_centroid_baseline,
    naive_backward_blowup,
    observation_centroid_baseline,
)
from .config import ExperimentConfig
from .losses import (
    BalancedDecayWeights,
    ablowitz_zeppetella_dirichlet_loss,
    ablowitz_zeppetella_front_band_samples,
    ablowitz_zeppetella_front_phase_loss,
    ablowitz_zeppetella_initial_condition_loss,
    bounded_residual_weights,
    boundary_neumann_loss,
    causal_weights,
    discrete_rk4_consistency_loss,
    expected_front_pde_loss,
    expected_front_gradient_residual_loss,
    front_area_contrast_loss,
    front_indicator_weights,
    front_local_gradient_residual_loss,
    front_profile_alignment_loss,
    front_level_set_alignment_loss,
    front_support_tversky_loss,
    front_speed_consistency_loss,
    gradient_residual_loss,
    intrinsic_phase_compatibility_losses,
    intrinsic_phase_initial_anchor_loss,
    known_initial_condition_loss,
    leading_edge_floor_loss,
    leading_edge_area_loss,
    leading_edge_distribution_loss,
    logit_phase_residual_loss,
    mass_floor_trajectory_loss,
    observed_support_area_loss,
    observed_support_tversky_loss,
    parabolic_mass_balance_loss,
    pde_residual,
    pde_residual_terms,
    radial_symmetry_loss,
    residual_cvar_loss,
    seed_regularization_loss,
    spatial_coefficient_regularization_loss,
    transverse_invariance_loss,
    time_slab_interface_loss,
)
from .metrics import front_boundary_metrics, front_speed_error_from_fields, origin_error, relative_l2, tensor_center
from .models import OriginPINN
from .plotting import (
    generated_figure_names,
    predict_field,
    save_initial_phase_contour_diagnostic_figure,
    save_observation_coverage_figure,
    save_phase_u_contour_diagnostic_figure,
    save_pinn_evolution_gif,
    save_pinn_rk4_comparison_figure,
    save_reconstruction_figure,
    save_residual_front_diagnostics_figure,
    save_spacetime_error_figure,
    save_training_diagnostics_figure,
)
from .rk4 import forward_ablowitz_zeppetella_rk4, forward_fisher_kpp_rk4
from .samplers import SobolCollocation
from .shooting import source_shooting_loss
from .simulate import (
    forward_ablowitz_zeppetella_exact,
    forward_fisher_kpp,
    interpolate_truth,
    observation_tensors,
    sample_observations,
    split_observations,
    truth_field_at,
)
from .utils import default_device, seed_everything, write_json


@dataclass
class SingleRunResult:
    seed: int
    origin: tuple[float, float]
    origin_error: float
    physics: dict[str, float]
    history: list[dict[str, float]]
    model: OriginPINN
    checkpoint_epoch: int = 0
    checkpoint_score: float | None = None


def _bin_losses(
    residual_sq: torch.Tensor,
    times: torch.Tensor,
    time_bins: int,
    t_end: float,
) -> torch.Tensor:
    ids = torch.clamp((times[:, 0] / t_end * time_bins).long(), 0, time_bins - 1)
    losses = []
    for idx in range(time_bins):
        mask = ids == idx
        if torch.any(mask):
            losses.append(residual_sq[mask].mean())
        else:
            losses.append(residual_sq.mean() * 0.0)
    return torch.stack(losses)


def _weighted_data_mse(
    pred: torch.Tensor,
    target: torch.Tensor,
    density_gain: float,
) -> torch.Tensor:
    err_sq = (pred - target) ** 2
    if density_gain <= 0.0:
        return err_sq.mean()
    weights = 1.0 + density_gain * target.detach().clamp_min(0.0)
    return torch.mean(weights * err_sq)


def _sample_rk4_teacher_points(
    rk4_truth,
    cfg: ExperimentConfig,
    n: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    candidate_n = max(4 * n, n + 1024)
    xyt = np.empty((candidate_n, 3), dtype=np.float64)
    xyt[:, 0] = rng.uniform(0.0, cfg.domain.box, size=candidate_n)
    xyt[:, 1] = rng.uniform(0.0, cfg.domain.box, size=candidate_n)
    xyt[:, 2] = rng.uniform(0.0, cfg.domain.t_end, size=candidate_n)
    late_fraction = float(np.clip(cfg.train.rk4_teacher_late_fraction, 0.0, 1.0))
    late_n = int(round(candidate_n * late_fraction))
    if late_n > 0:
        start = min(max(cfg.observations.start_time, 0.0), cfg.domain.t_end)
        xyt[:late_n, 2] = rng.uniform(start, cfg.domain.t_end, size=late_n)
    values = interpolate_truth(rk4_truth, xyt)
    activity = np.clip(values, 0.0, 1.0) * (1.0 - np.clip(values, 0.0, 1.0))
    low_front = ((values > 0.02) & (values < 0.30)).astype(np.float64)
    weights = 0.05 + activity + 0.50 * low_front
    weights = weights / np.sum(weights)
    replace_points = n > candidate_n
    idx = rng.choice(candidate_n, size=n, replace=replace_points, p=weights)
    return xyt[idx].astype(np.float32), values[idx, None].astype(np.float32)


def _rk4_teacher_batch_loss(
    model: OriginPINN,
    teacher_xyt: torch.Tensor | None,
    teacher_values: torch.Tensor | None,
    batch_size: int,
    density_gain: float,
    device: torch.device,
    *,
    t_low: float = 0.0,
    t_high: float | None = None,
) -> torch.Tensor:
    if teacher_xyt is None or teacher_values is None or len(teacher_xyt) == 0 or batch_size <= 0:
        return torch.zeros((), device=device)
    teacher_batch = min(max(1, int(batch_size)), len(teacher_xyt))
    teacher_idx = _masked_batch_indices(teacher_xyt, teacher_batch, device, t_low=t_low, t_high=t_high)
    if teacher_idx is None:
        return torch.zeros((), device=device)
    teacher_pred = model(teacher_xyt[teacher_idx, :2], teacher_xyt[teacher_idx, 2:3])
    return _weighted_data_mse(teacher_pred, teacher_values[teacher_idx], density_gain)


def _tensor_float(value: torch.Tensor | float | None) -> float:
    if value is None:
        return 0.0
    if isinstance(value, torch.Tensor):
        return float(value.detach().cpu())
    return float(value)


def _mean_positive(values: list[float]) -> float:
    finite = [float(value) for value in values if math.isfinite(float(value))]
    if not finite:
        return 0.0
    return float(sum(finite) / len(finite))


def _log_score(value: float, *, scale: float = 1.0) -> float:
    value = float(value)
    if not math.isfinite(value):
        return float("inf")
    return math.log1p(scale * max(0.0, value))


def _checkpoint_teacher_loss(
    model: OriginPINN,
    teacher_xyt: torch.Tensor | None,
    teacher_values: torch.Tensor | None,
    cfg: ExperimentConfig,
    density_gain: float,
) -> float:
    if teacher_xyt is None or teacher_values is None or len(teacher_xyt) == 0:
        return 0.0
    late_start = max(0.0, cfg.domain.t_end * 0.65)
    candidates = torch.where(teacher_xyt[:, 2] >= late_start - 1.0e-8)[0]
    if len(candidates) == 0:
        candidates = torch.arange(len(teacher_xyt), device=teacher_xyt.device)
    n = min(512, len(candidates))
    if n <= 0:
        return 0.0
    if n == len(candidates):
        idx = candidates
    else:
        pick = torch.linspace(0, len(candidates) - 1, n, device=teacher_xyt.device).long()
        idx = candidates[pick]
    with torch.no_grad():
        pred = model(teacher_xyt[idx, :2], teacher_xyt[idx, 2:3])
        loss = _weighted_data_mse(pred, teacher_values[idx], density_gain)
    return _tensor_float(loss)


def _checkpoint_composite_score(
    cfg: ExperimentConfig,
    *,
    validation_loss: float | None,
    data_loss: torch.Tensor,
    teacher_loss: float,
    pde_loss_value: torch.Tensor,
    ic_loss: torch.Tensor,
    front_terms: list[torch.Tensor],
    mass_terms: list[torch.Tensor],
) -> tuple[float, dict[str, float]]:
    validation_or_data = float(validation_loss) if validation_loss is not None else _tensor_float(data_loss)
    front_proxy = _mean_positive([_tensor_float(term) for term in front_terms])
    mass_proxy = _mean_positive([_tensor_float(term) for term in mass_terms])
    parts = {
        "validation": _log_score(validation_or_data, scale=50.0),
        "teacher": _log_score(teacher_loss, scale=50.0),
        "pde": _log_score(_tensor_float(pde_loss_value), scale=1.0),
        "ic": _log_score(_tensor_float(ic_loss), scale=1.0),
        "front": _log_score(front_proxy, scale=1.0),
        "mass": _log_score(mass_proxy, scale=1.0),
    }
    score = (
        cfg.train.checkpoint_validation_weight * parts["validation"]
        + cfg.train.checkpoint_teacher_weight * parts["teacher"]
        + cfg.train.checkpoint_pde_weight * parts["pde"]
        + cfg.train.checkpoint_initial_condition_weight * parts["ic"]
        + cfg.train.checkpoint_front_weight * parts["front"]
        + cfg.train.checkpoint_mass_weight * parts["mass"]
    )
    parts["score"] = float(score)
    parts["raw_validation_or_data"] = validation_or_data
    parts["raw_teacher"] = float(teacher_loss)
    parts["raw_pde"] = _tensor_float(pde_loss_value)
    parts["raw_front_proxy"] = front_proxy
    parts["raw_mass_proxy"] = mass_proxy
    return float(score), parts


def _training_checkpoint_path(cfg: ExperimentConfig, run_seed: int) -> Path:
    return cfg.out_dir / f"training_seed_{run_seed}_latest.pt"


def _torch_load_checkpoint(path: Path, device: torch.device) -> dict[str, object]:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


def _save_training_checkpoint(
    path: Path,
    *,
    cfg: ExperimentConfig,
    run_seed: int,
    epoch: int,
    model: OriginPINN,
    optimizer: torch.optim.Optimizer,
    history: list[dict[str, float]],
    best_validation_loss: float,
    best_checkpoint_score: float,
    best_checkpoint_parts: dict[str, float],
    best_epoch: int,
    best_state: dict[str, torch.Tensor] | None,
    rk4_pretrain_final_loss: float | None,
    elapsed_sec: float,
    reason: str,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "reason": reason,
        "saved_at_epoch": int(epoch),
        "run_seed": int(run_seed),
        "config": cfg.to_dict(),
        "model_state": {name: value.detach().cpu() for name, value in model.state_dict().items()},
        "optimizer_state": optimizer.state_dict(),
        "history": history,
        "best_validation_loss": float(best_validation_loss),
        "best_checkpoint_score": float(best_checkpoint_score),
        "best_checkpoint_parts": best_checkpoint_parts,
        "best_epoch": int(best_epoch),
        "best_state": (
            {name: value.detach().cpu() for name, value in best_state.items()}
            if best_state is not None
            else None
        ),
        "rk4_pretrain_final_loss": rk4_pretrain_final_loss,
        "elapsed_sec": float(elapsed_sec),
        "torch_rng_state": torch.random.get_rng_state(),
        "cuda_rng_state_all": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
        "numpy_rng_state": np.random.get_state(),
    }
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, tmp_path)
    for attempt in range(8):
        try:
            tmp_path.replace(path)
            break
        except PermissionError:
            if attempt == 7:
                raise
            time.sleep(0.25 * (attempt + 1))


def _load_training_checkpoint(
    path: Path,
    *,
    model: OriginPINN,
    optimizer: torch.optim.Optimizer | None,
    device: torch.device,
) -> dict[str, object] | None:
    if not path.exists():
        return None
    payload = _torch_load_checkpoint(path, device)
    model.load_state_dict(payload["model_state"])
    if optimizer is not None and payload.get("optimizer_state") is not None:
        optimizer.load_state_dict(payload["optimizer_state"])
    torch_state = payload.get("torch_rng_state")
    if isinstance(torch_state, torch.Tensor):
        torch.random.set_rng_state(torch_state.detach().cpu())
    cuda_states = payload.get("cuda_rng_state_all")
    if cuda_states is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(
            [state.detach().cpu().to(torch.uint8) for state in cuda_states if isinstance(state, torch.Tensor)]
        )
    numpy_state = payload.get("numpy_rng_state")
    if numpy_state is not None:
        np.random.set_state(numpy_state)
    return payload


def _front_geometry_summary(
    truth,
    model: OriginPINN,
    cfg: ExperimentConfig,
    device: torch.device,
    *,
    levels: tuple[float, ...] = (0.05, 0.10),
    n: int = 96,
    max_times: int = 14,
) -> dict[str, object]:
    if len(truth.times) <= max_times:
        times = truth.times
    else:
        idx = np.linspace(0, len(truth.times) - 1, max_times).astype(int)
        times = truth.times[idx]

    summary: dict[str, object] = {
        "levels": list(levels),
        "times": [float(t) for t in times],
        "truth_mass": [],
        "pinn_mass": [],
        "truth_active_band": [],
        "pinn_active_band": [],
        "area_above": {f"{level:.2f}": {"truth": [], "pinn": []} for level in levels},
        "boundary": {
            f"{level:.2f}": {
                "front_mae": [],
                "hausdorff": [],
                "truth_boundary_points": [],
                "pinn_boundary_points": [],
            }
            for level in levels
        },
    }
    fields_for_speed: dict[str, list[np.ndarray]] = {"truth": [], "pinn": []}
    xs_for_speed: np.ndarray | None = None
    for time_value in times:
        xs, true_field = truth_field_at(truth, float(time_value), n=n)
        xs_for_speed = xs
        _, pred = predict_field(model, float(time_value), n=n, device=device)
        fields_for_speed["truth"].append(true_field)
        fields_for_speed["pinn"].append(pred)
        summary["truth_mass"].append(float(true_field.mean()))
        summary["pinn_mass"].append(float(pred.mean()))
        summary["truth_active_band"].append(float(np.mean((true_field > 0.1) & (true_field < 0.9))))
        summary["pinn_active_band"].append(float(np.mean((pred > 0.1) & (pred < 0.9))))
        for level in levels:
            bucket = summary["area_above"][f"{level:.2f}"]
            bucket["truth"].append(float(np.mean(true_field > level)))
            bucket["pinn"].append(float(np.mean(pred > level)))
            boundary_metrics = front_boundary_metrics(xs, pred, true_field, level=level)
            boundary_bucket = summary["boundary"][f"{level:.2f}"]
            boundary_bucket["front_mae"].append(float(boundary_metrics["front_mae"]))
            boundary_bucket["hausdorff"].append(float(boundary_metrics["hausdorff"]))
            boundary_bucket["truth_boundary_points"].append(float(boundary_metrics["truth_boundary_points"]))
            boundary_bucket["pinn_boundary_points"].append(float(boundary_metrics["pred_boundary_points"]))

    mass_truth = np.asarray(summary["truth_mass"], dtype=np.float64)
    mass_pred = np.asarray(summary["pinn_mass"], dtype=np.float64)
    active_truth = np.asarray(summary["truth_active_band"], dtype=np.float64)
    active_pred = np.asarray(summary["pinn_active_band"], dtype=np.float64)
    summary["mass_mae"] = float(np.mean(np.abs(mass_pred - mass_truth)))
    summary["active_band_mae"] = float(np.mean(np.abs(active_pred - active_truth)))
    summary["area_mae"] = {}
    for level in levels:
        bucket = summary["area_above"][f"{level:.2f}"]
        truth_area = np.asarray(bucket["truth"], dtype=np.float64)
        pred_area = np.asarray(bucket["pinn"], dtype=np.float64)
        summary["area_mae"][f"{level:.2f}"] = float(np.mean(np.abs(pred_area - truth_area)))
        summary[f"area_above_{int(round(level * 1000)):03d}_mae"] = summary["area_mae"][f"{level:.2f}"]
        boundary_bucket = summary["boundary"][f"{level:.2f}"]
        front_mae = np.asarray(boundary_bucket["front_mae"], dtype=np.float64)
        hausdorff = np.asarray(boundary_bucket["hausdorff"], dtype=np.float64)
        summary[f"front_mae_{int(round(level * 1000)):03d}"] = (
            float(np.nanmean(front_mae)) if np.isfinite(front_mae).any() else None
        )
        summary[f"hausdorff_{int(round(level * 1000)):03d}"] = (
            float(np.nanmean(hausdorff)) if np.isfinite(hausdorff).any() else None
        )
    if xs_for_speed is not None:
        speed_mode = "x" if cfg.benchmark.kind == "ablowitz_zeppetella" else "radius"
        speed_summary = front_speed_error_from_fields(
            xs_for_speed,
            np.asarray(times, dtype=np.float64),
            fields_for_speed["pinn"],
            fields_for_speed["truth"],
            level=0.10,
            mode=speed_mode,
            center=(cfg.seed.center_x, cfg.seed.center_y),
        )
        summary["front_speed_error"] = speed_summary
        speed_mae = speed_summary.get("mae")
        summary["front_speed_mae_010"] = float(speed_mae) if speed_mae is not None and np.isfinite(speed_mae) else None
    return summary


class _AdaptiveLossBalancer:
    """Relative-progress loss balancer for multi-term PINN objectives."""

    def __init__(self, momentum: float, min_weight: float, max_weight: float, eps: float = 1.0e-8) -> None:
        self.momentum = float(momentum)
        self.min_weight = float(min_weight)
        self.max_weight = float(max_weight)
        self.eps = float(eps)
        self.initial: dict[str, float] = {}
        self.weights: dict[str, float] = {}

    def update(self, losses: dict[str, torch.Tensor]) -> dict[str, float]:
        if not losses:
            return {}
        ratios: dict[str, float] = {}
        for name, loss in losses.items():
            value = max(float(loss.detach().cpu()), self.eps)
            self.initial.setdefault(name, value)
            ratios[name] = value / max(self.initial[name], self.eps)
        mean_ratio = max(float(np.mean(list(ratios.values()))), self.eps)
        next_weights: dict[str, float] = {}
        for name, ratio in ratios.items():
            target = float(np.clip(ratio / mean_ratio, self.min_weight, self.max_weight))
            previous = self.weights.get(name, target)
            next_weights[name] = self.momentum * previous + (1.0 - self.momentum) * target
        mean_weight = max(float(np.mean(list(next_weights.values()))), self.eps)
        self.weights = {
            name: float(np.clip(weight / mean_weight, self.min_weight, self.max_weight))
            for name, weight in next_weights.items()
        }
        return dict(self.weights)


class _GradientNormLossBalancer:
    """Per-term gradient-norm balancer following gradient-pathology PINN work."""

    def __init__(
        self,
        parameters: list[torch.nn.Parameter],
        momentum: float,
        min_weight: float,
        max_weight: float,
        update_every: int,
        eps: float = 1.0e-10,
    ) -> None:
        self.parameters = [param for param in parameters if param.requires_grad]
        self.momentum = float(momentum)
        self.min_weight = float(min_weight)
        self.max_weight = float(max_weight)
        self.update_every = max(1, int(update_every))
        self.eps = float(eps)
        self.weights: dict[str, float] = {}

    def update(self, losses: dict[str, torch.Tensor], epoch: int) -> dict[str, float]:
        if not self.parameters or not losses:
            return dict(self.weights)
        if self.weights and epoch % self.update_every != 0:
            return dict(self.weights)
        norms: dict[str, float] = {}
        for name, loss in losses.items():
            if not loss.requires_grad:
                continue
            grads = torch.autograd.grad(
                loss,
                self.parameters,
                retain_graph=True,
                create_graph=False,
                allow_unused=True,
            )
            sq_norm = torch.zeros((), device=loss.device)
            for grad in grads:
                if grad is not None:
                    sq_norm = sq_norm + grad.detach().pow(2).sum()
            norms[name] = float(torch.sqrt(sq_norm).detach().cpu())
        positive = [max(value, self.eps) for value in norms.values() if np.isfinite(value) and value > 0.0]
        if not positive:
            return dict(self.weights)
        mean_norm = max(float(np.mean(positive)), self.eps)
        next_weights: dict[str, float] = {}
        for name, norm in norms.items():
            target = float(np.clip(mean_norm / max(norm, self.eps), self.min_weight, self.max_weight))
            previous = self.weights.get(name, target)
            next_weights[name] = self.momentum * previous + (1.0 - self.momentum) * target
        mean_weight = max(float(np.mean(list(next_weights.values()))), self.eps)
        self.weights = {
            name: float(np.clip(weight / mean_weight, self.min_weight, self.max_weight))
            for name, weight in next_weights.items()
        }
        return dict(self.weights)


def _gradient_balance_parameters(model: OriginPINN) -> list[torch.nn.Parameter]:
    params: list[torch.nn.Parameter] = []
    if hasattr(model.mlp, "out_layer"):
        params.extend(list(model.mlp.out_layer.parameters()))
    elif hasattr(model.mlp, "shape_net") and hasattr(model.mlp.shape_net, "out_layer"):
        params.extend(list(model.mlp.shape_net.out_layer.parameters()))
        params.extend(list(model.mlp.parameter_net.out_layer.parameters()))
    params.extend([model.pde.raw_diffusion, model.pde.raw_reaction])
    return [param for param in params if param.requires_grad]


def _residual_weight_exponent(cfg: ExperimentConfig, epoch: int) -> float:
    if cfg.train.residual_curriculum_epochs <= 0:
        return float(cfg.train.residual_weight_exponent_end)
    progress = min(1.0, max(0.0, epoch / float(cfg.train.residual_curriculum_epochs)))
    start = float(cfg.train.residual_weight_exponent_start)
    end = float(cfg.train.residual_weight_exponent_end)
    return start + progress * (end - start)


def _time_window(cfg: ExperimentConfig, epoch: int) -> tuple[float, float]:
    t_end = float(cfg.domain.t_end)
    if t_end <= 0.0:
        return 0.0, 0.0
    high = t_end
    if cfg.train.time_marching:
        ramp_epochs = cfg.train.time_marching_epochs or cfg.train.epochs
        progress = min(1.0, max(0.0, epoch / float(max(1, ramp_epochs))))
        start = min(max(float(cfg.train.time_marching_start_fraction), 0.0), 1.0) * t_end
        high = start + progress * (t_end - start)
    low = 0.0
    if cfg.train.time_slabs > 1:
        slabs = max(1, int(cfg.train.time_slabs))
        if cfg.train.time_slab_curriculum:
            progress = min(1.0, max(0.0, (epoch - 1) / float(max(1, cfg.train.epochs - 1))))
            slab = min(slabs - 1, int(progress * slabs))
            edge1 = t_end * (slab + 1) / slabs
            overlap = max(0.0, float(cfg.train.time_slab_overlap)) * t_end
            high = min(high, min(t_end, edge1 + overlap))
        else:
            slab = (epoch - 1) % slabs
            edge0 = t_end * slab / slabs
            edge1 = t_end * (slab + 1) / slabs
            overlap = max(0.0, float(cfg.train.time_slab_overlap)) * t_end
            low = max(0.0, edge0 - overlap)
            high = min(high, min(t_end, edge1 + overlap))
            if high <= low:
                high = min(t_end, edge1 + overlap)
    return low, max(low + 1.0e-8, min(high, t_end))


def _fractional_warmup_scale(epoch: int, total_epochs: int, start_fraction: float, warmup_fraction: float) -> float:
    start_fraction = float(np.clip(start_fraction, 0.0, 1.0))
    warmup_fraction = float(max(0.0, warmup_fraction))
    start_epoch = max(1, int(round(start_fraction * max(1, total_epochs))))
    if epoch < start_epoch:
        return 0.0
    if warmup_fraction <= 0.0:
        return 1.0
    warmup_epochs = max(1, int(round(warmup_fraction * max(1, total_epochs))))
    return float(np.clip((epoch - start_epoch + 1) / warmup_epochs, 0.0, 1.0))


def _scheduled_loss_scales(cfg: ExperimentConfig, epoch: int) -> dict[str, float]:
    """Curriculum multipliers for stiff parabolic-front PINN losses.

    Data, known IC, and boundary terms stay fully active. PDE, moving-front,
    level-set, mass-balance, and time-interface terms can be phased in to avoid
    the early ill-conditioning reported for composite PINN objectives.
    """

    pde = _fractional_warmup_scale(epoch, cfg.train.epochs, 0.0, cfg.train.pde_loss_warmup_fraction)
    front = _fractional_warmup_scale(
        epoch,
        cfg.train.epochs,
        cfg.train.front_loss_start_fraction,
        cfg.train.front_loss_warmup_fraction,
    )
    time_interface = _fractional_warmup_scale(
        epoch,
        cfg.train.epochs,
        cfg.train.time_interface_start_fraction,
        cfg.train.time_interface_warmup_fraction,
    )
    return {
        "pde": pde,
        "front": front,
        "time_interface": time_interface,
    }


def _masked_batch_indices(
    xyt: torch.Tensor,
    n: int,
    device: torch.device,
    *,
    t_low: float = 0.0,
    t_high: float | None = None,
    fallback_all: bool = True,
) -> torch.Tensor | None:
    if t_high is None:
        candidates = torch.arange(len(xyt), device=device)
    else:
        mask = (xyt[:, 2] >= float(t_low) - 1.0e-8) & (xyt[:, 2] <= float(t_high) + 1.0e-8)
        candidates = torch.where(mask)[0]
        if len(candidates) == 0:
            if not fallback_all:
                return None
            candidates = torch.arange(len(xyt), device=device)
    if len(candidates) == 0:
        return None
    return candidates[torch.randint(0, len(candidates), (n,), device=device)]


def _sample_curriculum_collocation(
    sampler: SobolCollocation,
    n: int,
    *,
    t_low: float,
    t_high: float,
    focus_fraction: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    if n <= 0:
        return sampler.sample(0)
    focus_fraction = float(np.clip(focus_fraction, 0.0, 1.0))
    if focus_fraction >= 1.0 - 1.0e-8:
        return sampler.sample(n, t_low=t_low, t_high=t_high)
    if focus_fraction <= 1.0e-8:
        return sampler.sample(n)

    focus_n = min(n, max(1, int(round(n * focus_fraction))))
    global_n = n - focus_n
    focus_xy, focus_t = sampler.sample(focus_n, t_low=t_low, t_high=t_high)
    if global_n <= 0:
        return focus_xy, focus_t
    global_xy, global_t = sampler.sample(global_n)
    return torch.cat([focus_xy, global_xy], dim=0), torch.cat([focus_t, global_t], dim=0)


def _inject_az_front_band_collocation(
    cfg: ExperimentConfig,
    model: OriginPINN,
    xy_col: torch.Tensor,
    t_col: torch.Tensor,
    device: torch.device,
    *,
    t_low: float,
    t_high: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    if cfg.benchmark.kind != "ablowitz_zeppetella" or cfg.weights.level_set_alignment <= 0.0:
        return xy_col, t_col
    n = min(len(xy_col) // 4, max(1, cfg.train.level_set_points))
    if n <= 0:
        return xy_col, t_col
    front_xy, front_t = ablowitz_zeppetella_front_band_samples(
        model,
        n,
        device,
        width=cfg.train.level_set_width,
        t_low=t_low,
        t_high=t_high,
        x_left=cfg.benchmark.x_left,
        x_right=cfg.benchmark.x_right,
        x0=cfg.benchmark.wave_x0,
    )
    if len(front_xy) == 0:
        return xy_col, t_col
    keep = max(0, len(xy_col) - len(front_xy))
    return torch.cat([xy_col[:keep], front_xy], dim=0), torch.cat([t_col[:keep], front_t], dim=0)


def _combine_loss_terms(
    terms: list[tuple[str, float, torch.Tensor]],
    balancer: _AdaptiveLossBalancer | None,
    grad_balancer: _GradientNormLossBalancer | None = None,
    *,
    epoch: int = 1,
) -> tuple[torch.Tensor, dict[str, float], dict[str, float]]:
    balanceable = {
        "data",
        "observation_support",
        "observation_support_area",
        "rk4_teacher",
        "pde",
        "phase_pde",
        "residual_cvar",
        "intrinsic_phase_initial",
        "intrinsic_phase_gradient_alignment",
        "intrinsic_phase_monotonicity",
        "bc",
        "seed_match",
        "seed_mass",
        "source_anchor",
        "shooting",
        "grad",
        "front_grad",
        "front_speed",
        "mass",
        "mass_floor",
        "expected_front_pde",
        "leading_edge",
        "leading_edge_area",
        "leading_edge_distribution",
        "radial_symmetry",
        "front_support_tversky",
        "front_contrast",
        "front_profile",
        "level_set",
        "transverse_invariance",
        "time_interface",
        "coefficient_field",
    }
    active = [(name, weight, loss) for name, weight, loss in terms if weight > 0.0]
    if not active:
        device = terms[0][2].device if terms else torch.device("cpu")
        return torch.zeros((), device=device), {}, {}
    adaptive_losses = {
        name: loss
        for name, _, loss in active
        if name in balanceable and float(loss.detach().cpu()) > 1.0e-10
    }
    adaptive = balancer.update(adaptive_losses) if balancer is not None else {}
    grad_adaptive = grad_balancer.update(adaptive_losses, epoch) if grad_balancer is not None else {}
    total = torch.zeros((), dtype=active[0][2].dtype, device=active[0][2].device)
    for name, weight, loss in active:
        total = total + float(weight) * float(adaptive.get(name, 1.0)) * float(grad_adaptive.get(name, 1.0)) * loss
    return total, adaptive, grad_adaptive


def _physics_parameter_anchor_loss(model: OriginPINN, device: torch.device) -> torch.Tensor:
    dtype = next(model.parameters()).dtype
    diffusion_ref = torch.as_tensor(model.reference_diffusion, dtype=dtype, device=device).clamp_min(1.0e-12)
    reaction_ref = torch.as_tensor(model.reference_reaction, dtype=dtype, device=device).clamp_min(1.0e-12)
    diffusion_ratio = model.pde.diffusion().clamp_min(1.0e-12) / diffusion_ref
    reaction_ratio = model.pde.reaction().clamp_min(1.0e-12) / reaction_ref
    return torch.log(diffusion_ratio).pow(2) + torch.log(reaction_ratio).pow(2)


def _pretrain_on_rk4_teacher(
    model: OriginPINN,
    cfg: ExperimentConfig,
    teacher_xyt: torch.Tensor | None,
    teacher_values: torch.Tensor | None,
    device: torch.device,
) -> float | None:
    if (
        cfg.train.rk4_pretrain_steps <= 0
        or cfg.train.rk4_pretrain_batch <= 0
        or teacher_xyt is None
        or teacher_values is None
        or len(teacher_xyt) == 0
    ):
        return None
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.train.rk4_pretrain_lr)
    last_loss = None
    report_every = max(1, cfg.train.rk4_pretrain_steps // 4)
    for step in range(1, cfg.train.rk4_pretrain_steps + 1):
        optimizer.zero_grad()
        loss = _rk4_teacher_batch_loss(
            model,
            teacher_xyt,
            teacher_values,
            cfg.train.rk4_pretrain_batch,
            cfg.weights.data_density_gain,
            device,
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
        optimizer.step()
        last_loss = float(loss.detach().cpu())
        if step == 1 or step % report_every == 0 or step == cfg.train.rk4_pretrain_steps:
            print(f"rk4_pretrain step={step:4d} teacher_mse={last_loss:.3e}")
    return last_loss


def train_single(
    cfg: ExperimentConfig,
    observations_xyt: torch.Tensor,
    observations_values: torch.Tensor,
    validation_xyt: torch.Tensor | None,
    validation_values: torch.Tensor | None,
    teacher_xyt: torch.Tensor | None,
    teacher_values: torch.Tensor | None,
    run_seed: int,
    device: torch.device,
) -> SingleRunResult:
    seed_everything(run_seed)
    model = OriginPINN(cfg.domain, cfg.pde, cfg.seed, cfg.model).to(device)
    is_az_benchmark = cfg.benchmark.kind == "ablowitz_zeppetella"
    if cfg.warm_start.mode == "shooting_prefit":
        centroid_cfg = replace(cfg, warm_start=replace(cfg.warm_start, mode="centroid"))
        initial_center = _warm_start_center_from_observations(centroid_cfg, observations_xyt, observations_values)
        model.source.set_center(initial_center)
        _prefit_source_with_shooting(model, cfg, observations_xyt, observations_values)
        warm_start = tensor_center(model)
    else:
        warm_start = _warm_start_center_from_observations(cfg, observations_xyt, observations_values)
    if cfg.model.hard_initial_condition and not cfg.model.use_source_envelope and not is_az_benchmark:
        # In known-IC forward runs the synthetic source is not inferred through SourceHead.
        # Align the diagnostic source parameters with the enforced initial condition so
        # origin metrics describe the forward setup instead of a stale neutral head.
        warm_start = (cfg.seed.center_x, cfg.seed.center_y)
    print(f"warm_start mode={cfg.warm_start.mode} center=({warm_start[0]:.3f}, {warm_start[1]:.3f})")
    model.source.set_center(warm_start)
    warm_start_tensor = torch.tensor(warm_start, dtype=torch.float32, device=device)
    source_ids = {id(param) for param in model.source.parameters()}
    source_params = [param for param in model.parameters() if id(param) in source_ids]
    other_params = [param for param in model.parameters() if id(param) not in source_ids]
    resume_path = _training_checkpoint_path(cfg, run_seed)
    resume_payload = None
    if cfg.train.resume_from_checkpoint and resume_path.exists():
        resume_payload = _load_training_checkpoint(resume_path, model=model, optimizer=None, device=device)
        print(
            f"resuming training checkpoint: {resume_path} "
            f"epoch={int(resume_payload.get('saved_at_epoch', 0))}"
        )
    rk4_pretrain_final_loss = (
        resume_payload.get("rk4_pretrain_final_loss")
        if resume_payload is not None
        else _pretrain_on_rk4_teacher(model, cfg, teacher_xyt, teacher_values, device)
    )
    optimizer = torch.optim.Adam(
        [
            {"params": other_params, "lr": cfg.train.lr},
            {"params": source_params, "lr": cfg.train.lr * cfg.train.source_lr_multiplier},
        ]
    )
    mask_kind = cfg.geo.mask_kind if cfg.geo.enabled else "box"
    sampler = SobolCollocation(cfg.domain.box, cfg.domain.t_end, device, seed=run_seed, mask_kind=mask_kind)
    decay = BalancedDecayWeights(cfg.train.time_bins, cfg.train.decay_beta, device)
    loss_balancer = (
        _AdaptiveLossBalancer(
            cfg.train.adaptive_loss_momentum,
            cfg.train.adaptive_loss_min,
            cfg.train.adaptive_loss_max,
        )
        if cfg.train.adaptive_loss_balancing
        else None
    )
    grad_loss_balancer = (
        _GradientNormLossBalancer(
            _gradient_balance_parameters(model),
            cfg.train.adaptive_loss_momentum,
            cfg.train.adaptive_loss_min,
            cfg.train.adaptive_loss_max,
            cfg.train.gradient_norm_balance_every,
        )
        if cfg.train.gradient_norm_balancing
        else None
    )
    history: list[dict[str, float]] = []
    best_validation_loss = float("inf")
    best_checkpoint_score = float("inf")
    best_checkpoint_parts: dict[str, float] = {}
    best_state: dict[str, torch.Tensor] | None = None
    best_epoch = 0
    start_epoch = 1
    elapsed_offset = 0.0
    if resume_payload is not None:
        if resume_payload.get("optimizer_state") is not None:
            optimizer.load_state_dict(resume_payload["optimizer_state"])
        history = list(resume_payload.get("history", []))
        best_validation_loss = float(resume_payload.get("best_validation_loss", float("inf")))
        best_checkpoint_score = float(resume_payload.get("best_checkpoint_score", float("inf")))
        best_checkpoint_parts = dict(resume_payload.get("best_checkpoint_parts", {}))
        loaded_best_state = resume_payload.get("best_state")
        if loaded_best_state is not None:
            best_state = {
                name: value.detach().cpu().clone()
                for name, value in loaded_best_state.items()
            }
        best_epoch = int(resume_payload.get("best_epoch", 0))
        start_epoch = min(int(resume_payload.get("saved_at_epoch", 0)) + 1, cfg.train.epochs + 1)
        elapsed_offset = float(resume_payload.get("elapsed_sec", 0.0))
    min_checkpoint_epoch = max(1, int(math.ceil(cfg.train.epochs * cfg.train.checkpoint_min_epoch_fraction)))
    start = time.time() - elapsed_offset

    last_completed_epoch = start_epoch - 1
    previous_sigint_handler = None
    sigint_handler_installed = False

    def _save_latest_training_state(reason: str) -> None:
        if not cfg.train.resume_from_checkpoint:
            return
        _save_training_checkpoint(
            resume_path,
            cfg=cfg,
            run_seed=run_seed,
            epoch=max(0, int(last_completed_epoch)),
            model=model,
            optimizer=optimizer,
            history=history,
            best_validation_loss=best_validation_loss,
            best_checkpoint_score=best_checkpoint_score,
            best_checkpoint_parts=best_checkpoint_parts,
            best_epoch=best_epoch,
            best_state=best_state,
            rk4_pretrain_final_loss=rk4_pretrain_final_loss,
            elapsed_sec=time.time() - start,
            reason=reason,
        )

    def _handle_sigint(signum, frame) -> None:  # noqa: ANN001
        try:
            _save_latest_training_state("sigint")
            print(f"saved interrupt checkpoint: {resume_path} epoch={last_completed_epoch}")
        finally:
            raise KeyboardInterrupt

    if cfg.train.resume_from_checkpoint:
        try:
            previous_sigint_handler = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _handle_sigint)
            sigint_handler_installed = True
        except ValueError:
            sigint_handler_installed = False

    for epoch in range(start_epoch, cfg.train.epochs + 1):
        last_completed_epoch = epoch - 1
        window_t_low, window_t_high = _time_window(cfg, epoch)
        optimizer.zero_grad()
        if cfg.train.observation_batch > 0 or cfg.train.time_window_observations:
            obs_batch = cfg.train.observation_batch if cfg.train.observation_batch > 0 else len(observations_xyt)
            obs_idx = _masked_batch_indices(
                observations_xyt,
                min(obs_batch, len(observations_xyt)),
                device,
                t_low=window_t_low,
                t_high=window_t_high if cfg.train.time_window_observations else None,
            )
            if obs_idx is None:
                obs_xyt_batch = observations_xyt
                obs_values_batch = observations_values
            else:
                obs_xyt_batch = observations_xyt[obs_idx]
                obs_values_batch = observations_values[obs_idx]
        else:
            obs_xyt_batch = observations_xyt
            obs_values_batch = observations_values
        pred = model(obs_xyt_batch[:, :2], obs_xyt_batch[:, 2:3])
        data_loss = _weighted_data_mse(pred, obs_values_batch, cfg.weights.data_density_gain)
        if cfg.weights.observation_support > 0.0:
            observation_support_loss = observed_support_tversky_loss(
                pred,
                obs_values_batch,
                temperature=cfg.train.observation_support_temperature,
                false_positive_weight=cfg.train.observation_support_false_positive_weight,
                false_negative_weight=cfg.train.observation_support_false_negative_weight,
                focal_gamma=cfg.train.observation_support_focal_gamma,
            )
        else:
            observation_support_loss = torch.zeros((), device=device)
        if cfg.weights.observation_support_area > 0.0:
            observation_support_area_loss = observed_support_area_loss(
                pred,
                obs_values_batch,
                temperature=cfg.train.observation_support_temperature,
                false_positive_weight=cfg.train.observation_support_false_positive_weight,
                false_negative_weight=cfg.train.observation_support_false_negative_weight,
            )
        else:
            observation_support_area_loss = torch.zeros((), device=device)
        if cfg.weights.rk4_teacher > 0.0:
            rk4_teacher_loss = _rk4_teacher_batch_loss(
                model,
                teacher_xyt,
                teacher_values,
                cfg.train.rk4_teacher_batch,
                cfg.weights.data_density_gain,
                device,
                t_low=window_t_low,
                t_high=(
                    window_t_high
                    if cfg.train.time_window_teacher and (cfg.train.time_marching or cfg.train.time_slabs > 1)
                    else None
                ),
            )
        else:
            rk4_teacher_loss = torch.zeros((), device=device)

        if cfg.train.time_marching or cfg.train.time_slabs > 1:
            xy_col, t_col = _sample_curriculum_collocation(
                sampler,
                cfg.train.collocation_points,
                t_low=window_t_low,
                t_high=window_t_high,
                focus_fraction=cfg.train.time_window_focus_fraction,
            )
        else:
            xy_col, t_col = sampler.sample(cfg.train.collocation_points)
        xy_col, t_col = _inject_az_front_band_collocation(
            cfg,
            model,
            xy_col,
            t_col,
            device,
            t_low=window_t_low,
            t_high=window_t_high,
        )
        residual, u_col, u_xy_col, _, _ = pde_residual_terms(model, xy_col, t_col)
        residual_sq = residual.pow(2).flatten()
        residual_exponent = _residual_weight_exponent(cfg, epoch)
        front_weights = front_indicator_weights(
            u_col,
            u_xy_col,
            cfg.weights.front_pde_alpha,
            cfg.weights.front_pde_gradient,
        ).flatten()
        point_weights = bounded_residual_weights(residual_sq, exponent=residual_exponent) * front_weights
        weighted_residual_sq = residual_sq * point_weights
        bins = _bin_losses(weighted_residual_sq, t_col, cfg.train.time_bins, cfg.domain.t_end)
        time_weights = causal_weights(bins, cfg.train.causal_eps) * decay.update(bins)
        pde_loss_value = torch.sum(time_weights * bins) / time_weights.sum().clamp_min(1.0e-12)
        if cfg.weights.phase_pde > 0.0:
            phase_points = min(
                len(xy_col),
                max(512, cfg.train.expected_front_points, cfg.train.level_set_points),
            )
            if phase_points < len(xy_col):
                head = phase_points // 2
                tail = phase_points - head
                xy_phase = torch.cat([xy_col[:head], xy_col[-tail:]], dim=0)
                t_phase = torch.cat([t_col[:head], t_col[-tail:]], dim=0)
            else:
                xy_phase, t_phase = xy_col, t_col
            phase_pde_loss = logit_phase_residual_loss(
                model,
                xy_phase,
                t_phase,
                active_low=cfg.train.phase_residual_low,
                active_high=cfg.train.phase_residual_high,
                temperature=cfg.train.phase_residual_temperature,
                residual_clip=cfg.train.phase_residual_clip,
            )
        else:
            phase_pde_loss = torch.zeros((), device=device)
        if cfg.weights.residual_cvar > 0.0:
            residual_cvar = residual_cvar_loss(weighted_residual_sq, cfg.train.residual_cvar_fraction)
        else:
            residual_cvar = torch.zeros((), device=device)
        if cfg.weights.intrinsic_phase_initial > 0.0 and cfg.train.intrinsic_phase_anchor_points > 0:
            intrinsic_phase_initial = intrinsic_phase_initial_anchor_loss(
                model,
                cfg.seed,
                cfg.train.intrinsic_phase_anchor_points,
                device,
                level=cfg.train.intrinsic_phase_anchor_level,
                band=cfg.train.intrinsic_phase_anchor_band,
                sign_margin=cfg.train.intrinsic_phase_anchor_sign_margin,
                benchmark_kind=cfg.benchmark.kind,
                x_left=cfg.benchmark.x_left,
                x_right=cfg.benchmark.x_right,
                x0=cfg.benchmark.wave_x0,
            )
        else:
            intrinsic_phase_initial = torch.zeros((), device=device)
        if (
            (cfg.weights.intrinsic_phase_gradient_alignment > 0.0 or cfg.weights.intrinsic_phase_monotonicity > 0.0)
            and cfg.train.intrinsic_phase_compatibility_points > 0
        ):
            compat_points = min(cfg.train.intrinsic_phase_compatibility_points, len(xy_col))
            phase_compat = intrinsic_phase_compatibility_losses(
                model,
                xy_col[:compat_points],
                t_col[:compat_points],
                active_low=cfg.train.intrinsic_phase_compatibility_low,
                active_high=cfg.train.intrinsic_phase_compatibility_high,
                temperature=cfg.train.intrinsic_phase_compatibility_temperature,
                min_grad=cfg.train.intrinsic_phase_compatibility_min_grad,
            )
            intrinsic_phase_gradient_alignment = phase_compat["alignment"]
            intrinsic_phase_monotonicity = phase_compat["monotonicity"]
        else:
            intrinsic_phase_gradient_alignment = torch.zeros((), device=device)
            intrinsic_phase_monotonicity = torch.zeros((), device=device)

        if cfg.weights.boundary > 0.0 and cfg.train.boundary_points > 0:
            if is_az_benchmark:
                bc_loss = ablowitz_zeppetella_dirichlet_loss(
                    model,
                    cfg.train.boundary_points,
                    device,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                bc_loss = boundary_neumann_loss(model, cfg.train.boundary_points, device)
        else:
            bc_loss = torch.zeros((), device=device)
        if cfg.weights.initial_condition > 0.0 and cfg.train.seed_points > 0:
            if is_az_benchmark:
                ic_loss = ablowitz_zeppetella_initial_condition_loss(
                    model,
                    cfg.train.seed_points,
                    device,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                ic_loss = known_initial_condition_loss(model, cfg.seed, cfg.train.seed_points, device)
        else:
            ic_loss = torch.zeros((), device=device)
        if (cfg.weights.seed_match > 0.0 or cfg.weights.seed_mass > 0.0) and cfg.train.seed_points > 0:
            seed_match, seed_mass = seed_regularization_loss(model, cfg.train.seed_points, device)
        else:
            seed_match = torch.zeros((), device=device)
            seed_mass = torch.zeros((), device=device)
        if cfg.weights.source_anchor > 0.0:
            source_anchor = torch.mean(((model.source.center() - warm_start_tensor) / cfg.domain.box) ** 2)
        else:
            source_anchor = torch.zeros((), device=device)
        if cfg.weights.shooting > 0.0:
            shooting_loss = source_shooting_loss(
                model,
                observations_xyt,
                observations_values,
                grid=cfg.train.shooting_grid,
                steps=cfg.train.shooting_steps,
                max_points=cfg.train.shooting_points,
            )
        else:
            shooting_loss = torch.zeros((), device=device)
        if cfg.weights.front_gradient > 0.0:
            subset = min(128, len(xy_col))
            front_grad_terms = [front_local_gradient_residual_loss(model, xy_col[:subset], t_col[:subset])]
            if cfg.train.front_gradient_expected_points > 0:
                front_grad_terms.append(
                    expected_front_gradient_residual_loss(
                        model,
                        cfg.train.front_gradient_expected_points,
                        device,
                        width=cfg.train.expected_front_width,
                        speed_factor=cfg.train.expected_front_speed_factor,
                        level=cfg.train.expected_front_level,
                        max_points=min(128, cfg.train.front_gradient_expected_points),
                        t_low=window_t_low,
                        t_high=window_t_high,
                    )
                )
            front_grad_loss = torch.stack(front_grad_terms).mean()
            grad_loss = torch.zeros((), device=device)
        elif cfg.weights.gradient > 0.0:
            subset = min(128, len(xy_col))
            grad_loss = gradient_residual_loss(model, xy_col[:subset], t_col[:subset])
            front_grad_loss = torch.zeros((), device=device)
        else:
            grad_loss = torch.zeros((), device=device)
            front_grad_loss = torch.zeros((), device=device)
        if cfg.weights.front_speed > 0.0 and cfg.train.front_speed_points > 0:
            fs_subset = min(cfg.train.front_speed_points, len(xy_col))
            front_speed_loss = front_speed_consistency_loss(
                model,
                xy_col[:fs_subset],
                t_col[:fs_subset],
                max_points=cfg.train.front_speed_max_points,
                min_grad=cfg.train.front_speed_min_grad,
                use_curvature_correction=cfg.train.use_front_curvature_correction,
                curvature_correction_weight=cfg.train.front_curvature_correction_weight,
            )
        else:
            front_speed_loss = torch.zeros((), device=device)
        if cfg.weights.expected_front_pde > 0.0 and cfg.train.expected_front_points > 0:
            expected_front_loss = expected_front_pde_loss(
                model,
                cfg.train.expected_front_points,
                device,
                width=cfg.train.expected_front_width,
                speed_factor=cfg.train.expected_front_speed_factor,
                level=cfg.train.expected_front_level,
                front_alpha=cfg.weights.front_pde_alpha,
                front_gradient=cfg.weights.front_pde_gradient,
            )
        else:
            expected_front_loss = torch.zeros((), device=device)
        if cfg.weights.leading_edge > 0.0 and cfg.train.expected_front_points > 0:
            leading_edge_loss = leading_edge_floor_loss(
                model,
                cfg.train.expected_front_points,
                device,
                width=cfg.train.expected_front_width,
                speed_factor=cfg.train.expected_front_speed_factor,
                level=cfg.train.expected_front_level,
            )
        else:
            leading_edge_loss = torch.zeros((), device=device)
        if cfg.weights.leading_edge_area > 0.0 and cfg.train.leading_edge_area_times > 0:
            leading_edge_area = leading_edge_area_loss(
                model,
                cfg.train.leading_edge_area_times,
                cfg.train.leading_edge_area_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            leading_edge_area = torch.zeros((), device=device)
        if (
            cfg.weights.leading_edge_distribution > 0.0
            and cfg.train.leading_edge_distribution_times > 0
            and cfg.train.leading_edge_distribution_grid > 1
        ):
            leading_edge_distribution = leading_edge_distribution_loss(
                model,
                cfg.train.leading_edge_distribution_times,
                cfg.train.leading_edge_distribution_grid,
                device,
            )
        else:
            leading_edge_distribution = torch.zeros((), device=device)
        if cfg.weights.radial_symmetry > 0.0 and cfg.train.radial_symmetry_groups > 0:
            radial_symmetry = radial_symmetry_loss(
                model,
                cfg.train.radial_symmetry_groups,
                cfg.train.radial_symmetry_angles,
                device,
                t_low=window_t_low,
                t_high=window_t_high,
            )
        else:
            radial_symmetry = torch.zeros((), device=device)
        if cfg.weights.front_contrast > 0.0 and cfg.train.front_contrast_times > 0:
            front_contrast = front_area_contrast_loss(
                model,
                cfg.train.front_contrast_times,
                cfg.train.front_contrast_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            front_contrast = torch.zeros((), device=device)
        if cfg.weights.front_profile > 0.0 and cfg.train.front_profile_points > 0:
            front_profile = front_profile_alignment_loss(
                model,
                cfg.train.front_profile_points,
                device,
                width=cfg.train.front_profile_width,
                t_low=window_t_low,
                t_high=window_t_high,
            )
        else:
            front_profile = torch.zeros((), device=device)
        if cfg.weights.level_set_alignment > 0.0 and cfg.train.level_set_points > 0:
            if is_az_benchmark:
                level_set_loss = ablowitz_zeppetella_front_phase_loss(
                    model,
                    cfg.train.level_set_points,
                    device,
                    width=cfg.train.level_set_width,
                    t_low=window_t_low,
                    t_high=window_t_high,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                level_set_loss = front_level_set_alignment_loss(
                    model,
                    cfg.train.level_set_points,
                    device,
                    width=cfg.train.level_set_width,
                    t_low=window_t_low,
                    t_high=window_t_high,
                )
        else:
            level_set_loss = torch.zeros((), device=device)
        if cfg.weights.transverse_invariance > 0.0 and cfg.train.transverse_invariance_points > 0:
            transverse_loss = transverse_invariance_loss(
                model,
                cfg.train.transverse_invariance_points,
                device,
            )
        else:
            transverse_loss = torch.zeros((), device=device)
        if cfg.weights.mass_balance > 0.0:
            mass_loss = parabolic_mass_balance_loss(
                model,
                cfg.train.mass_balance_times,
                cfg.train.mass_balance_grid,
                device,
            )
        else:
            mass_loss = torch.zeros((), device=device)
        if cfg.weights.mass_floor > 0.0:
            mass_floor_loss = mass_floor_trajectory_loss(
                model,
                cfg.train.mass_balance_times,
                cfg.train.mass_balance_grid,
                device,
            )
        else:
            mass_floor_loss = torch.zeros((), device=device)
        if cfg.weights.front_support_tversky > 0.0 and cfg.train.leading_edge_area_times > 0:
            front_support_tversky = front_support_tversky_loss(
                model,
                cfg.train.leading_edge_area_times,
                cfg.train.leading_edge_area_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            front_support_tversky = torch.zeros((), device=device)
        if cfg.weights.time_interface > 0.0 and cfg.train.time_slabs > 1 and cfg.train.time_interface_points > 0:
            time_interface_loss = time_slab_interface_loss(
                model,
                cfg.train.time_interface_points,
                device,
                slabs=cfg.train.time_slabs,
                width=cfg.train.time_interface_width,
            )
        else:
            time_interface_loss = torch.zeros((), device=device)
        if cfg.weights.discrete_rk4 > 0.0 and cfg.train.discrete_rk4_times > 0 and cfg.train.discrete_rk4_grid > 2:
            discrete_rk4_loss = discrete_rk4_consistency_loss(
                model,
                cfg.train.discrete_rk4_times,
                cfg.train.discrete_rk4_grid,
                device,
                dt_fraction=cfg.train.discrete_rk4_dt_fraction,
                t_low=window_t_low,
                t_high=window_t_high,
            )
        else:
            discrete_rk4_loss = torch.zeros((), device=device)
        if cfg.weights.physics_parameter_anchor > 0.0:
            physics_anchor_loss = _physics_parameter_anchor_loss(model, device)
        else:
            physics_anchor_loss = torch.zeros((), device=device)
        if cfg.weights.coefficient_field > 0.0 and model.has_spatial_coefficients():
            coefficient_field_loss = spatial_coefficient_regularization_loss(
                model,
                xy_col[: min(len(xy_col), 512)],
            )
        else:
            coefficient_field_loss = torch.zeros((), device=device)
        sparse_loss = model.sparse_last_layer_l1() if cfg.weights.sparse > 0.0 else torch.zeros((), device=device)
        schedule = _scheduled_loss_scales(cfg, epoch)
        pde_weight = cfg.weights.pde * schedule["pde"]
        front_weight = schedule["front"]
        time_interface_weight = cfg.weights.time_interface * schedule["time_interface"]

        total, adaptive_weights, grad_adaptive_weights = _combine_loss_terms(
            [
                ("data", cfg.weights.data, data_loss),
                ("observation_support", cfg.weights.observation_support, observation_support_loss),
                ("observation_support_area", cfg.weights.observation_support_area, observation_support_area_loss),
                ("rk4_teacher", cfg.weights.rk4_teacher, rk4_teacher_loss),
                ("pde", pde_weight, pde_loss_value),
                ("phase_pde", cfg.weights.phase_pde * schedule["pde"], phase_pde_loss),
                ("residual_cvar", cfg.weights.residual_cvar * schedule["pde"], residual_cvar),
                ("intrinsic_phase_initial", cfg.weights.intrinsic_phase_initial, intrinsic_phase_initial),
                (
                    "intrinsic_phase_gradient_alignment",
                    cfg.weights.intrinsic_phase_gradient_alignment * front_weight,
                    intrinsic_phase_gradient_alignment,
                ),
                (
                    "intrinsic_phase_monotonicity",
                    cfg.weights.intrinsic_phase_monotonicity * front_weight,
                    intrinsic_phase_monotonicity,
                ),
                ("ic", cfg.weights.initial_condition, ic_loss),
                ("bc", cfg.weights.boundary, bc_loss),
                ("seed_match", cfg.weights.seed_match, seed_match),
                ("seed_mass", cfg.weights.seed_mass, seed_mass),
                ("source_anchor", cfg.weights.source_anchor, source_anchor),
                ("shooting", cfg.weights.shooting, shooting_loss),
                ("grad", cfg.weights.gradient, grad_loss),
                ("front_grad", cfg.weights.front_gradient * front_weight, front_grad_loss),
                ("front_speed", cfg.weights.front_speed * front_weight, front_speed_loss),
                ("expected_front_pde", cfg.weights.expected_front_pde * front_weight, expected_front_loss),
                ("leading_edge", cfg.weights.leading_edge * front_weight, leading_edge_loss),
                ("leading_edge_area", cfg.weights.leading_edge_area * front_weight, leading_edge_area),
                (
                    "leading_edge_distribution",
                    cfg.weights.leading_edge_distribution * front_weight,
                    leading_edge_distribution,
                ),
                ("radial_symmetry", cfg.weights.radial_symmetry * front_weight, radial_symmetry),
                ("front_contrast", cfg.weights.front_contrast * front_weight, front_contrast),
                ("front_profile", cfg.weights.front_profile * front_weight, front_profile),
                ("level_set", cfg.weights.level_set_alignment * front_weight, level_set_loss),
                (
                    "transverse_invariance",
                    cfg.weights.transverse_invariance * front_weight,
                    transverse_loss,
                ),
                ("mass", cfg.weights.mass_balance * front_weight, mass_loss),
                ("mass_floor", cfg.weights.mass_floor * front_weight, mass_floor_loss),
                (
                    "front_support_tversky",
                    cfg.weights.front_support_tversky * front_weight,
                    front_support_tversky,
                ),
                ("time_interface", time_interface_weight, time_interface_loss),
                ("discrete_rk4", cfg.weights.discrete_rk4 * schedule["pde"], discrete_rk4_loss),
                ("physics_anchor", cfg.weights.physics_parameter_anchor, physics_anchor_loss),
                ("coefficient_field", cfg.weights.coefficient_field, coefficient_field_loss),
                ("sparse", cfg.weights.sparse, sparse_loss),
            ],
            loss_balancer,
            grad_loss_balancer,
            epoch=epoch,
        )
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
        optimizer.step()

        if cfg.train.rar_interval > 0 and epoch % cfg.train.rar_interval == 0:
            sampler.refresh(
                model,
                cfg.train.rar_candidates,
                cfg.train.rar_keep,
                front_alpha=cfg.weights.front_pde_alpha,
                front_gradient=cfg.weights.front_pde_gradient,
                residual_weight=cfg.train.rar_residual_weight,
                gradient_weight=cfg.train.rar_gradient_weight,
                activity_weight=cfg.train.rar_activity_weight,
                t_low=window_t_low,
                t_high=window_t_high,
            )

        if epoch == 1 or epoch % cfg.train.print_every == 0 or epoch == cfg.train.epochs:
            validation_loss = None
            should_validate = (
                validation_xyt is not None
                and validation_values is not None
                and len(validation_xyt) > 0
                and (
                    epoch == 1
                    or epoch == cfg.train.epochs
                    or cfg.train.validation_every <= 0
                    or epoch % cfg.train.validation_every == 0
                )
            )
            if should_validate:
                with torch.no_grad():
                    validation_pred = model(validation_xyt[:, :2], validation_xyt[:, 2:3])
                    validation_loss = float(torch.mean((validation_pred - validation_values) ** 2).detach().cpu())
                teacher_checkpoint_loss = _checkpoint_teacher_loss(
                    model,
                    teacher_xyt,
                    teacher_values,
                    cfg,
                    cfg.weights.data_density_gain,
                )
                checkpoint_score, checkpoint_parts = _checkpoint_composite_score(
                    cfg,
                    validation_loss=validation_loss,
                    data_loss=data_loss,
                    teacher_loss=teacher_checkpoint_loss,
                    pde_loss_value=pde_loss_value,
                    ic_loss=ic_loss,
                    front_terms=[
                        front_grad_loss,
                        front_speed_loss,
                        expected_front_loss,
                        leading_edge_loss,
                        leading_edge_area,
                        front_contrast,
                        front_profile,
                        level_set_loss,
                        intrinsic_phase_initial,
                        intrinsic_phase_gradient_alignment,
                        intrinsic_phase_monotonicity,
                        transverse_loss,
                        front_support_tversky,
                        observation_support_loss,
                        observation_support_area_loss,
                    ],
                    mass_terms=[mass_loss, mass_floor_loss],
                )
                can_save_checkpoint = epoch >= min_checkpoint_epoch or epoch == cfg.train.epochs
                if (
                    cfg.train.restore_best_validation
                    and can_save_checkpoint
                    and checkpoint_score < best_checkpoint_score
                ):
                    best_validation_loss = validation_loss
                    best_checkpoint_score = checkpoint_score
                    best_checkpoint_parts = checkpoint_parts
                    best_epoch = epoch
                    best_state = {
                        name: value.detach().cpu().clone()
                        for name, value in model.state_dict().items()
                    }
            else:
                teacher_checkpoint_loss = None
                checkpoint_score = None
                checkpoint_parts = {}
            center = tensor_center(model)
            row = {
                "epoch": float(epoch),
                "total": float(total.detach().cpu()),
                "data": float(data_loss.detach().cpu()),
                "observation_support": float(observation_support_loss.detach().cpu()),
                "observation_support_area": float(observation_support_area_loss.detach().cpu()),
                "rk4_teacher": float(rk4_teacher_loss.detach().cpu()),
                "pde": float(pde_loss_value.detach().cpu()),
                "phase_pde": float(phase_pde_loss.detach().cpu()),
                "residual_cvar": float(residual_cvar.detach().cpu()),
                "intrinsic_phase_initial": float(intrinsic_phase_initial.detach().cpu()),
                "intrinsic_phase_gradient_alignment": float(intrinsic_phase_gradient_alignment.detach().cpu()),
                "intrinsic_phase_monotonicity": float(intrinsic_phase_monotonicity.detach().cpu()),
                "ic": float(ic_loss.detach().cpu()),
                "bc": float(bc_loss.detach().cpu()),
                "seed_match": float(seed_match.detach().cpu()),
                "seed_mass": float(seed_mass.detach().cpu()),
                "source_anchor": float(source_anchor.detach().cpu()),
                "shooting": float(shooting_loss.detach().cpu()),
                "grad": float(grad_loss.detach().cpu()),
                "front_grad": float(front_grad_loss.detach().cpu()),
                "front_speed": float(front_speed_loss.detach().cpu()),
                "expected_front_pde": float(expected_front_loss.detach().cpu()),
                "leading_edge": float(leading_edge_loss.detach().cpu()),
                "leading_edge_area": float(leading_edge_area.detach().cpu()),
                "leading_edge_distribution": float(leading_edge_distribution.detach().cpu()),
                "radial_symmetry": float(radial_symmetry.detach().cpu()),
                "front_contrast": float(front_contrast.detach().cpu()),
                "front_profile": float(front_profile.detach().cpu()),
                "level_set": float(level_set_loss.detach().cpu()),
                "transverse_invariance": float(transverse_loss.detach().cpu()),
                "mass": float(mass_loss.detach().cpu()),
                "mass_floor": float(mass_floor_loss.detach().cpu()),
                "front_support_tversky": float(front_support_tversky.detach().cpu()),
                "time_interface": float(time_interface_loss.detach().cpu()),
                "discrete_rk4": float(discrete_rk4_loss.detach().cpu()),
                "physics_anchor": float(physics_anchor_loss.detach().cpu()),
                "coefficient_field": float(coefficient_field_loss.detach().cpu()),
                "sparse": float(sparse_loss.detach().cpu()),
                "residual_exponent": float(residual_exponent),
                "schedule_pde": float(schedule["pde"]),
                "schedule_front": float(schedule["front"]),
                "schedule_time_interface": float(schedule["time_interface"]),
                "time_window_low": float(window_t_low),
                "time_window_high": float(window_t_high),
                "front_weight_mean": float(front_weights.detach().mean().cpu()),
                "diffusion": float(model.pde.diffusion().detach().cpu()),
                "reaction": float(model.pde.reaction().detach().cpu()),
                "velocity_x": float(model.pde.velocity[0].detach().cpu()),
                "velocity_y": float(model.pde.velocity[1].detach().cpu()),
                "origin_error": origin_error(center, cfg.seed),
                "elapsed_sec": time.time() - start,
            }
            row.update(model.coefficient_stats(xy_col[: min(len(xy_col), 512)]))
            if validation_loss is not None:
                row["validation_data"] = validation_loss
                row["best_validation_data"] = (
                    float(best_validation_loss) if math.isfinite(best_validation_loss) else validation_loss
                )
                row["best_validation_epoch"] = float(best_epoch)
                row["checkpoint_score"] = float(checkpoint_score)
                row["best_checkpoint_score"] = (
                    float(best_checkpoint_score) if math.isfinite(best_checkpoint_score) else 0.0
                )
                row["checkpoint_teacher"] = float(teacher_checkpoint_loss)
                row["checkpoint_raw_pde"] = checkpoint_parts.get("raw_pde", 0.0)
                row["checkpoint_raw_front_proxy"] = checkpoint_parts.get("raw_front_proxy", 0.0)
                row["checkpoint_raw_mass_proxy"] = checkpoint_parts.get("raw_mass_proxy", 0.0)
                row["checkpoint_min_epoch"] = float(min_checkpoint_epoch)
            if rk4_pretrain_final_loss is not None:
                row["rk4_pretrain_final"] = rk4_pretrain_final_loss
            for name, value in adaptive_weights.items():
                row[f"aw_{name}"] = float(value)
            for name, value in grad_adaptive_weights.items():
                row[f"gnw_{name}"] = float(value)
            history.append(row)
            print(
                f"seed={run_seed} ep={epoch:5d} "
                f"loss={row['total']:.3e} data={row['data']:.2e} "
                f"pde={row['pde']:.2e} rw_exp={row['residual_exponent']:.2f} "
                f"origin_err={row['origin_error']:.3f}"
            )
        last_completed_epoch = epoch
        if (
            cfg.train.resume_from_checkpoint
            and cfg.train.training_checkpoint_every > 0
            and (epoch % cfg.train.training_checkpoint_every == 0 or epoch == cfg.train.epochs)
        ):
            _save_training_checkpoint(
                resume_path,
                cfg=cfg,
                run_seed=run_seed,
                epoch=epoch,
                model=model,
                optimizer=optimizer,
                history=history,
                best_validation_loss=best_validation_loss,
                best_checkpoint_score=best_checkpoint_score,
                best_checkpoint_parts=best_checkpoint_parts,
                best_epoch=best_epoch,
                best_state=best_state,
                rk4_pretrain_final_loss=rk4_pretrain_final_loss,
                elapsed_sec=time.time() - start,
                reason="epoch_end",
            )

    if sigint_handler_installed:
        signal.signal(signal.SIGINT, previous_sigint_handler)

    if cfg.train.adam_to_lbfgs and cfg.train.lbfgs_steps > 0:
        _lbfgs_polish(model, cfg, observations_xyt, observations_values, sampler, device)

    if best_state is not None:
        model.load_state_dict({name: value.to(device) for name, value in best_state.items()})
        print(
            f"restored best composite checkpoint: epoch={best_epoch} "
            f"score={best_checkpoint_score:.3e} validation_mse={best_validation_loss:.3e}"
        )

    center = tensor_center(model)
    return SingleRunResult(
        seed=run_seed,
        origin=center,
        origin_error=origin_error(center, cfg.seed),
        physics=model.physics_dict(),
        history=history,
        model=model,
        checkpoint_epoch=best_epoch,
        checkpoint_score=best_checkpoint_score if math.isfinite(best_checkpoint_score) else None,
    )


def _warm_start_center_from_observations(
    cfg: ExperimentConfig,
    observations_xyt: torch.Tensor,
    observations_values: torch.Tensor,
) -> tuple[float, float]:
    if cfg.warm_start.mode == "neutral":
        return (0.5 * cfg.domain.box, 0.5 * cfg.domain.box)

    latest = torch.max(observations_xyt[:, 2])
    mask = torch.isclose(observations_xyt[:, 2], latest)
    xy = observations_xyt[mask, :2]
    weights = observations_values[mask, 0].clamp_min(0.0)
    if torch.sum(weights) <= 1.0e-12:
        centroid = xy.mean(dim=0)
    else:
        centroid = torch.sum(xy * weights[:, None], dim=0) / torch.sum(weights)

    if cfg.warm_start.mode == "centroid":
        corrected = centroid.clamp(0.0, cfg.domain.box)
        return (float(corrected[0].detach().cpu()), float(corrected[1].detach().cpu()))

    if cfg.warm_start.mode != "drift_corrected":
        raise ValueError(
            f"Unknown warm_start.mode={cfg.warm_start.mode!r}; "
            "expected 'drift_corrected', 'centroid', 'neutral', or 'shooting_prefit'."
        )

    drift = torch.tensor(
        [cfg.pde.velocity_x, cfg.pde.velocity_y],
        dtype=centroid.dtype,
        device=centroid.device,
    )
    corrected = (centroid - drift * latest).clamp(0.0, cfg.domain.box)
    return (float(corrected[0].detach().cpu()), float(corrected[1].detach().cpu()))


def _prefit_source_with_shooting(
    model: OriginPINN,
    cfg: ExperimentConfig,
    observations_xyt: torch.Tensor,
    observations_values: torch.Tensor,
) -> None:
    if cfg.train.shooting_prefit_steps <= 0:
        return
    params = list(model.source.parameters())
    if cfg.model.learn_drift:
        params.append(model.pde.velocity)
    optimizer = torch.optim.Adam(params, lr=3.0e-2)
    for _ in range(cfg.train.shooting_prefit_steps):
        optimizer.zero_grad()
        loss = source_shooting_loss(
            model,
            observations_xyt,
            observations_values,
            grid=cfg.train.shooting_grid,
            steps=cfg.train.shooting_steps,
            max_points=cfg.train.shooting_points,
        )
        loss.backward()
        optimizer.step()


def _lbfgs_polish(
    model: OriginPINN,
    cfg: ExperimentConfig,
    observations_xyt: torch.Tensor,
    observations_values: torch.Tensor,
    sampler: SobolCollocation,
    device: torch.device,
) -> None:
    opt = torch.optim.LBFGS(model.parameters(), max_iter=cfg.train.lbfgs_steps, tolerance_grad=1.0e-7)
    xy_col, t_col = sampler.sample(min(cfg.train.collocation_points, 2048))
    is_az_benchmark = cfg.benchmark.kind == "ablowitz_zeppetella"
    xy_col, t_col = _inject_az_front_band_collocation(
        cfg,
        model,
        xy_col,
        t_col,
        device,
        t_low=0.0,
        t_high=cfg.domain.t_end,
    )

    def closure() -> torch.Tensor:
        opt.zero_grad()
        pred = model(observations_xyt[:, :2], observations_xyt[:, 2:3])
        data_loss = _weighted_data_mse(pred, observations_values, cfg.weights.data_density_gain)
        if cfg.weights.observation_support > 0.0:
            observation_support_loss = observed_support_tversky_loss(
                pred,
                observations_values,
                temperature=cfg.train.observation_support_temperature,
                false_positive_weight=cfg.train.observation_support_false_positive_weight,
                false_negative_weight=cfg.train.observation_support_false_negative_weight,
                focal_gamma=cfg.train.observation_support_focal_gamma,
            )
        else:
            observation_support_loss = torch.zeros((), device=device)
        if cfg.weights.observation_support_area > 0.0:
            observation_support_area_loss = observed_support_area_loss(
                pred,
                observations_values,
                temperature=cfg.train.observation_support_temperature,
                false_positive_weight=cfg.train.observation_support_false_positive_weight,
                false_negative_weight=cfg.train.observation_support_false_negative_weight,
            )
        else:
            observation_support_area_loss = torch.zeros((), device=device)
        residual, u_col, u_xy_col, _, _ = pde_residual_terms(model, xy_col, t_col)
        front_weights = front_indicator_weights(
            u_col,
            u_xy_col,
            cfg.weights.front_pde_alpha,
            cfg.weights.front_pde_gradient,
        )
        residual_sq = residual.pow(2).flatten()
        point_weights = bounded_residual_weights(
            residual_sq,
            exponent=cfg.train.residual_weight_exponent_end,
        ) * front_weights.flatten()
        pde_loss_value = torch.mean(point_weights * residual_sq)
        weighted_residual_sq = point_weights * residual_sq
        if cfg.weights.phase_pde > 0.0:
            phase_points = min(
                len(xy_col),
                max(512, cfg.train.expected_front_points, cfg.train.level_set_points),
            )
            if phase_points < len(xy_col):
                head = phase_points // 2
                tail = phase_points - head
                xy_phase = torch.cat([xy_col[:head], xy_col[-tail:]], dim=0)
                t_phase = torch.cat([t_col[:head], t_col[-tail:]], dim=0)
            else:
                xy_phase, t_phase = xy_col, t_col
            phase_pde_loss = logit_phase_residual_loss(
                model,
                xy_phase,
                t_phase,
                active_low=cfg.train.phase_residual_low,
                active_high=cfg.train.phase_residual_high,
                temperature=cfg.train.phase_residual_temperature,
                residual_clip=cfg.train.phase_residual_clip,
            )
        else:
            phase_pde_loss = torch.zeros((), device=device)
        if cfg.weights.residual_cvar > 0.0:
            residual_cvar = residual_cvar_loss(weighted_residual_sq, cfg.train.residual_cvar_fraction)
        else:
            residual_cvar = torch.zeros((), device=device)
        if cfg.weights.intrinsic_phase_initial > 0.0 and cfg.train.intrinsic_phase_anchor_points > 0:
            intrinsic_phase_initial = intrinsic_phase_initial_anchor_loss(
                model,
                cfg.seed,
                min(cfg.train.intrinsic_phase_anchor_points, 512),
                device,
                level=cfg.train.intrinsic_phase_anchor_level,
                band=cfg.train.intrinsic_phase_anchor_band,
                sign_margin=cfg.train.intrinsic_phase_anchor_sign_margin,
                benchmark_kind=cfg.benchmark.kind,
                x_left=cfg.benchmark.x_left,
                x_right=cfg.benchmark.x_right,
                x0=cfg.benchmark.wave_x0,
            )
        else:
            intrinsic_phase_initial = torch.zeros((), device=device)
        if (
            (cfg.weights.intrinsic_phase_gradient_alignment > 0.0 or cfg.weights.intrinsic_phase_monotonicity > 0.0)
            and cfg.train.intrinsic_phase_compatibility_points > 0
        ):
            compat_points = min(cfg.train.intrinsic_phase_compatibility_points, len(xy_col), 256)
            phase_compat = intrinsic_phase_compatibility_losses(
                model,
                xy_col[:compat_points],
                t_col[:compat_points],
                active_low=cfg.train.intrinsic_phase_compatibility_low,
                active_high=cfg.train.intrinsic_phase_compatibility_high,
                temperature=cfg.train.intrinsic_phase_compatibility_temperature,
                min_grad=cfg.train.intrinsic_phase_compatibility_min_grad,
            )
            intrinsic_phase_gradient_alignment = phase_compat["alignment"]
            intrinsic_phase_monotonicity = phase_compat["monotonicity"]
        else:
            intrinsic_phase_gradient_alignment = torch.zeros((), device=device)
            intrinsic_phase_monotonicity = torch.zeros((), device=device)
        if cfg.weights.boundary > 0.0 and cfg.train.boundary_points > 0:
            if is_az_benchmark:
                bc_loss = ablowitz_zeppetella_dirichlet_loss(
                    model,
                    min(cfg.train.boundary_points, 512),
                    device,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                bc_loss = boundary_neumann_loss(model, cfg.train.boundary_points, device)
        else:
            bc_loss = torch.zeros((), device=device)
        if cfg.weights.initial_condition > 0.0 and cfg.train.seed_points > 0:
            if is_az_benchmark:
                ic_loss = ablowitz_zeppetella_initial_condition_loss(
                    model,
                    min(cfg.train.seed_points, 512),
                    device,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                ic_loss = known_initial_condition_loss(model, cfg.seed, cfg.train.seed_points, device)
        else:
            ic_loss = torch.zeros((), device=device)
        if cfg.weights.front_speed > 0.0 and cfg.train.front_speed_points > 0:
            fs_subset = min(cfg.train.front_speed_points, len(xy_col))
            front_speed_loss = front_speed_consistency_loss(
                model,
                xy_col[:fs_subset],
                t_col[:fs_subset],
                max_points=cfg.train.front_speed_max_points,
                min_grad=cfg.train.front_speed_min_grad,
                use_curvature_correction=cfg.train.use_front_curvature_correction,
                curvature_correction_weight=cfg.train.front_curvature_correction_weight,
            )
        else:
            front_speed_loss = torch.zeros((), device=device)
        if cfg.weights.expected_front_pde > 0.0 and cfg.train.expected_front_points > 0:
            expected_front_loss = expected_front_pde_loss(
                model,
                min(cfg.train.expected_front_points, 256),
                device,
                width=cfg.train.expected_front_width,
                speed_factor=cfg.train.expected_front_speed_factor,
                level=cfg.train.expected_front_level,
                front_alpha=cfg.weights.front_pde_alpha,
                front_gradient=cfg.weights.front_pde_gradient,
            )
        else:
            expected_front_loss = torch.zeros((), device=device)
        if cfg.weights.leading_edge > 0.0 and cfg.train.expected_front_points > 0:
            leading_edge_loss = leading_edge_floor_loss(
                model,
                min(cfg.train.expected_front_points, 256),
                device,
                width=cfg.train.expected_front_width,
                speed_factor=cfg.train.expected_front_speed_factor,
                level=cfg.train.expected_front_level,
            )
        else:
            leading_edge_loss = torch.zeros((), device=device)
        if cfg.weights.leading_edge_area > 0.0 and cfg.train.leading_edge_area_times > 0:
            leading_edge_area = leading_edge_area_loss(
                model,
                cfg.train.leading_edge_area_times,
                cfg.train.leading_edge_area_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            leading_edge_area = torch.zeros((), device=device)
        if (
            cfg.weights.leading_edge_distribution > 0.0
            and cfg.train.leading_edge_distribution_times > 0
            and cfg.train.leading_edge_distribution_grid > 1
        ):
            leading_edge_distribution = leading_edge_distribution_loss(
                model,
                cfg.train.leading_edge_distribution_times,
                cfg.train.leading_edge_distribution_grid,
                device,
            )
        else:
            leading_edge_distribution = torch.zeros((), device=device)
        if cfg.weights.radial_symmetry > 0.0 and cfg.train.radial_symmetry_groups > 0:
            radial_symmetry = radial_symmetry_loss(
                model,
                cfg.train.radial_symmetry_groups,
                cfg.train.radial_symmetry_angles,
                device,
            )
        else:
            radial_symmetry = torch.zeros((), device=device)
        if cfg.weights.front_contrast > 0.0 and cfg.train.front_contrast_times > 0:
            front_contrast = front_area_contrast_loss(
                model,
                cfg.train.front_contrast_times,
                cfg.train.front_contrast_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            front_contrast = torch.zeros((), device=device)
        if cfg.weights.front_profile > 0.0 and cfg.train.front_profile_points > 0:
            front_profile = front_profile_alignment_loss(
                model,
                cfg.train.front_profile_points,
                device,
                width=cfg.train.front_profile_width,
            )
        else:
            front_profile = torch.zeros((), device=device)
        if cfg.weights.level_set_alignment > 0.0 and cfg.train.level_set_points > 0:
            if is_az_benchmark:
                level_set_loss = ablowitz_zeppetella_front_phase_loss(
                    model,
                    min(cfg.train.level_set_points, 256),
                    device,
                    width=cfg.train.level_set_width,
                    x_left=cfg.benchmark.x_left,
                    x_right=cfg.benchmark.x_right,
                    x0=cfg.benchmark.wave_x0,
                )
            else:
                level_set_loss = front_level_set_alignment_loss(
                    model,
                    min(cfg.train.level_set_points, 256),
                    device,
                    width=cfg.train.level_set_width,
                )
        else:
            level_set_loss = torch.zeros((), device=device)
        if cfg.weights.transverse_invariance > 0.0 and cfg.train.transverse_invariance_points > 0:
            transverse_loss = transverse_invariance_loss(
                model,
                min(cfg.train.transverse_invariance_points, 512),
                device,
            )
        else:
            transverse_loss = torch.zeros((), device=device)
        if cfg.weights.mass_balance > 0.0:
            mass_loss = parabolic_mass_balance_loss(
                model,
                cfg.train.mass_balance_times,
                cfg.train.mass_balance_grid,
                device,
            )
        else:
            mass_loss = torch.zeros((), device=device)
        if cfg.weights.mass_floor > 0.0:
            mass_floor_loss = mass_floor_trajectory_loss(
                model,
                cfg.train.mass_balance_times,
                cfg.train.mass_balance_grid,
                device,
            )
        else:
            mass_floor_loss = torch.zeros((), device=device)
        if cfg.weights.front_support_tversky > 0.0 and cfg.train.leading_edge_area_times > 0:
            front_support_tversky = front_support_tversky_loss(
                model,
                cfg.train.leading_edge_area_times,
                cfg.train.leading_edge_area_grid,
                device,
                temperature=cfg.train.leading_edge_area_temperature,
            )
        else:
            front_support_tversky = torch.zeros((), device=device)
        if cfg.weights.time_interface > 0.0 and cfg.train.time_slabs > 1 and cfg.train.time_interface_points > 0:
            time_interface_loss = time_slab_interface_loss(
                model,
                min(cfg.train.time_interface_points, 256),
                device,
                slabs=cfg.train.time_slabs,
                width=cfg.train.time_interface_width,
            )
        else:
            time_interface_loss = torch.zeros((), device=device)
        if cfg.weights.discrete_rk4 > 0.0 and cfg.train.discrete_rk4_times > 0 and cfg.train.discrete_rk4_grid > 2:
            discrete_rk4_loss = discrete_rk4_consistency_loss(
                model,
                cfg.train.discrete_rk4_times,
                cfg.train.discrete_rk4_grid,
                device,
                dt_fraction=cfg.train.discrete_rk4_dt_fraction,
            )
        else:
            discrete_rk4_loss = torch.zeros((), device=device)
        if (cfg.weights.seed_match > 0.0 or cfg.weights.seed_mass > 0.0) and cfg.train.seed_points > 0:
            seed_match, seed_mass = seed_regularization_loss(model, cfg.train.seed_points, device)
        else:
            seed_match = torch.zeros((), device=device)
            seed_mass = torch.zeros((), device=device)
        if cfg.weights.physics_parameter_anchor > 0.0:
            physics_anchor_loss = _physics_parameter_anchor_loss(model, device)
        else:
            physics_anchor_loss = torch.zeros((), device=device)
        if cfg.weights.coefficient_field > 0.0 and model.has_spatial_coefficients():
            coefficient_field_loss = spatial_coefficient_regularization_loss(
                model,
                xy_col[: min(len(xy_col), 512)],
            )
        else:
            coefficient_field_loss = torch.zeros((), device=device)
        loss = (
            cfg.weights.data * data_loss
            + cfg.weights.observation_support * observation_support_loss
            + cfg.weights.observation_support_area * observation_support_area_loss
            + cfg.weights.pde * pde_loss_value
            + cfg.weights.phase_pde * phase_pde_loss
            + cfg.weights.residual_cvar * residual_cvar
            + cfg.weights.intrinsic_phase_initial * intrinsic_phase_initial
            + cfg.weights.intrinsic_phase_gradient_alignment * intrinsic_phase_gradient_alignment
            + cfg.weights.intrinsic_phase_monotonicity * intrinsic_phase_monotonicity
            + cfg.weights.initial_condition * ic_loss
            + cfg.weights.boundary * bc_loss
            + cfg.weights.seed_match * seed_match
            + cfg.weights.seed_mass * seed_mass
            + cfg.weights.front_speed * front_speed_loss
            + cfg.weights.expected_front_pde * expected_front_loss
            + cfg.weights.leading_edge * leading_edge_loss
            + cfg.weights.leading_edge_area * leading_edge_area
            + cfg.weights.leading_edge_distribution * leading_edge_distribution
            + cfg.weights.radial_symmetry * radial_symmetry
            + cfg.weights.front_contrast * front_contrast
            + cfg.weights.front_profile * front_profile
            + cfg.weights.level_set_alignment * level_set_loss
            + cfg.weights.transverse_invariance * transverse_loss
            + cfg.weights.mass_balance * mass_loss
            + cfg.weights.mass_floor * mass_floor_loss
            + cfg.weights.front_support_tversky * front_support_tversky
            + cfg.weights.time_interface * time_interface_loss
            + cfg.weights.discrete_rk4 * discrete_rk4_loss
            + cfg.weights.physics_parameter_anchor * physics_anchor_loss
            + cfg.weights.coefficient_field * coefficient_field_loss
            + cfg.weights.sparse * model.sparse_last_layer_l1()
        )
        loss.backward()
        return loss

    opt.step(closure)


def run_experiment(cfg: ExperimentConfig) -> dict[str, object]:
    device = default_device()
    cfg.out_dir.mkdir(parents=True, exist_ok=True)
    print(f"device={device} out_dir={cfg.out_dir}")

    rng = np.random.default_rng(cfg.base_seed)
    is_az_benchmark = cfg.benchmark.kind == "ablowitz_zeppetella"
    if is_az_benchmark:
        truth = forward_ablowitz_zeppetella_exact(
            cfg.domain,
            x_left=cfg.benchmark.x_left,
            x_right=cfg.benchmark.x_right,
            x0=cfg.benchmark.wave_x0,
        )
    else:
        truth = forward_fisher_kpp(cfg.domain, cfg.pde, cfg.seed)
    observations = sample_observations(truth, cfg.domain, cfg.observations, rng)
    train_observations, validation_observations = split_observations(
        observations,
        cfg.observations.validation_fraction,
        rng,
    )
    obs_xyt, obs_values = observation_tensors(train_observations, device)
    val_xyt, val_values = observation_tensors(validation_observations, device)
    teacher_xyt = None
    teacher_values = None
    rk4_truth = None
    rk4_runtime_sec = None
    needs_rk4_teacher = cfg.train.rk4_teacher_pool > 0 and (
        (cfg.weights.rk4_teacher > 0.0 and cfg.train.rk4_teacher_batch > 0)
        or (cfg.train.rk4_pretrain_steps > 0 and cfg.train.rk4_pretrain_batch > 0)
    )
    if needs_rk4_teacher:
        rk4_start = time.time()
        if is_az_benchmark:
            rk4_truth = forward_ablowitz_zeppetella_rk4(
                cfg.domain,
                cfg.pde,
                x_left=cfg.benchmark.x_left,
                x_right=cfg.benchmark.x_right,
                x0=cfg.benchmark.wave_x0,
            )
        else:
            rk4_truth = forward_fisher_kpp_rk4(cfg.domain, cfg.pde, cfg.seed)
        rk4_runtime_sec = time.time() - rk4_start
        teacher_np, teacher_values_np = _sample_rk4_teacher_points(
            rk4_truth,
            cfg,
            cfg.train.rk4_teacher_pool,
            rng,
        )
        teacher_xyt = torch.tensor(teacher_np, dtype=torch.float32, device=device)
        teacher_values = torch.tensor(teacher_values_np, dtype=torch.float32, device=device)

    baseline_results: list[BaselineResult] = [
        observation_centroid_baseline(train_observations, cfg.seed),
        drift_corrected_observation_centroid_baseline(train_observations, cfg.domain, cfg.pde, cfg.seed),
        naive_backward_blowup(truth, cfg.domain, cfg.pde),
    ]
    if cfg.run_classical_baseline:
        baseline_results.append(
            differentiable_seed_baseline(
                train_observations,
                cfg.domain,
                cfg.pde,
                cfg.seed,
                epochs=cfg.baseline_epochs,
                device=device,
            )
        )

    runs = []
    for member in range(cfg.ensemble):
        runs.append(
            train_single(
                cfg,
                obs_xyt,
                obs_values,
                val_xyt,
                val_values,
                teacher_xyt,
                teacher_values,
                cfg.base_seed + member,
                device,
            )
        )

    best = min(runs, key=lambda r: r.origin_error)
    with torch.no_grad():
        train_pred = best.model(obs_xyt[:, :2], obs_xyt[:, 2:3])
        train_observation_mse = float(torch.mean((train_pred - obs_values) ** 2).detach().cpu())
        if len(val_xyt) > 0:
            val_pred = best.model(val_xyt[:, :2], val_xyt[:, 2:3])
            validation_observation_mse = float(torch.mean((val_pred - val_values) ** 2).detach().cpu())
        else:
            validation_observation_mse = None
    _, final_truth = truth_field_at(truth, cfg.domain.t_end, n=96)
    _, final_pred = predict_field(best.model, cfg.domain.t_end, n=96, device=device)
    pinn_final_abs_error = np.abs(final_pred - final_truth)
    pinn_final_time_relative_l2 = relative_l2(final_pred, final_truth)
    front_geometry = _front_geometry_summary(truth, best.model, cfg, device)
    if rk4_truth is None:
        rk4_start = time.time()
        if is_az_benchmark:
            rk4_truth = forward_ablowitz_zeppetella_rk4(
                cfg.domain,
                cfg.pde,
                x_left=cfg.benchmark.x_left,
                x_right=cfg.benchmark.x_right,
                x0=cfg.benchmark.wave_x0,
            )
        else:
            rk4_truth = forward_fisher_kpp_rk4(cfg.domain, cfg.pde, cfg.seed)
        rk4_runtime_sec = time.time() - rk4_start
    else:
        rk4_runtime_sec = float(rk4_runtime_sec or 0.0)
    _, final_rk4 = truth_field_at(rk4_truth, cfg.domain.t_end, n=96)
    rk4_final_abs_error = np.abs(final_rk4 - final_truth)
    rk4_final_time_relative_l2 = relative_l2(final_rk4, final_truth)
    pinn_vs_rk4_final_relative_l2 = relative_l2(final_pred, final_rk4)
    diagnostic_fields_path = cfg.out_dir / "diagnostic_fields.npz"
    final_xs = np.linspace(0.0, cfg.domain.box, final_truth.shape[0])
    x_grid, y_grid = np.meshgrid(final_xs, final_xs, indexing="ij")
    phase_xy = torch.tensor(
        np.stack([x_grid.reshape(-1), y_grid.reshape(-1)], axis=1),
        dtype=torch.float32,
        device=device,
    )
    phase_t = torch.full((len(phase_xy), 1), cfg.domain.t_end, dtype=torch.float32, device=device)
    with torch.no_grad():
        final_phase = best.model.phase(phase_xy, phase_t).detach().cpu().numpy().reshape(final_truth.shape)
    np.savez_compressed(
        diagnostic_fields_path,
        x=final_xs,
        final_time=np.array([cfg.domain.t_end], dtype=np.float64),
        truth_final=final_truth,
        pinn_final=final_pred,
        pinn_phase_final=final_phase,
        rk4_final=final_rk4,
        pinn_signed_error=final_pred - final_truth,
        pinn_abs_error=pinn_final_abs_error,
        rk4_abs_error=rk4_final_abs_error,
    )
    rk4_train_values = interpolate_truth(rk4_truth, train_observations.xyt)[:, None]
    rk4_train_observation_mse = float(np.mean((rk4_train_values - train_observations.values) ** 2))
    if len(validation_observations.xyt) > 0:
        rk4_val_values = interpolate_truth(rk4_truth, validation_observations.xyt)[:, None]
        rk4_validation_observation_mse = float(np.mean((rk4_val_values - validation_observations.values) ** 2))
    else:
        rk4_validation_observation_mse = None
    ensemble_centers = [run.origin for run in runs]
    save_reconstruction_figure(
        cfg.out_dir / "reconstruction.png",
        truth,
        best.model,
        cfg.domain,
        cfg.observations,
        cfg.seed,
        device,
        ensemble_centers=ensemble_centers,
    )
    save_observation_coverage_figure(
        cfg.out_dir / "observation_coverage.png",
        train_observations,
        validation_observations,
        cfg.domain,
    )
    save_spacetime_error_figure(
        cfg.out_dir / "spacetime_error.png",
        truth,
        best.model,
        cfg.domain,
        device,
    )
    save_residual_front_diagnostics_figure(
        cfg.out_dir / "residual_front_diagnostics.png",
        truth,
        best.model,
        cfg.domain,
        device,
        time_value=cfg.domain.t_end,
        front_alpha=cfg.weights.front_pde_alpha,
        front_gradient=cfg.weights.front_pde_gradient,
        use_curvature_correction=cfg.train.use_front_curvature_correction,
        curvature_correction_weight=cfg.train.front_curvature_correction_weight,
    )
    save_initial_phase_contour_diagnostic_figure(
        cfg.out_dir / "initial_phase_contour_diagnostic.png",
        best.model,
        cfg.domain,
        cfg.seed,
        device,
        level=cfg.train.intrinsic_phase_anchor_level,
        benchmark_kind=cfg.benchmark.kind,
        x_left=cfg.benchmark.x_left,
        x_right=cfg.benchmark.x_right,
        x0=cfg.benchmark.wave_x0,
    )
    save_phase_u_contour_diagnostic_figure(
        cfg.out_dir / "phase_u_contour_diagnostic.png",
        truth,
        best.model,
        cfg.domain,
        device,
        time_value=cfg.domain.t_end,
        level=cfg.train.intrinsic_phase_anchor_level,
    )
    rk4_compare_metrics = {
        "pinn_final_relative_l2": pinn_final_time_relative_l2,
        "rk4_final_relative_l2": rk4_final_time_relative_l2,
        "pinn_vs_rk4_final_relative_l2": pinn_vs_rk4_final_relative_l2,
        "pinn_validation_mse": validation_observation_mse,
        "rk4_validation_mse": rk4_validation_observation_mse,
    }
    save_pinn_rk4_comparison_figure(
        cfg.out_dir / "pinn_vs_rk4_comparison.png",
        truth,
        rk4_truth,
        best.model,
        cfg.domain,
        device,
        rk4_compare_metrics,
        time_value=cfg.domain.t_end,
    )
    save_training_diagnostics_figure(
        cfg.out_dir / "training_diagnostics.png",
        best.history,
        true_diffusion=cfg.pde.diffusion,
        true_reaction=cfg.pde.reaction,
    )
    gif_status = "trained_visualization"
    gif_warning = None
    if cfg.train.epochs < 50:
        gif_status = "diagnostic_only_low_epoch"
        gif_warning = "DIAGNOSTIC ONLY: low-epoch smoke run; do not interpret as converged PINN accuracy."
    elif pinn_final_time_relative_l2 > 1.0:
        gif_status = "diagnostic_high_error"
        gif_warning = "WARNING: high final relative L2; inspect metrics before interpreting the animation."
    elif pinn_final_time_relative_l2 > 0.5:
        gif_status = "diagnostic_moderate_error"
        gif_warning = "CHECK METRICS: PINN error is still large enough to make the animation qualitative only."
    gif_caption = (
        f"status={gif_status}, epochs={cfg.train.epochs}, final relative L2={pinn_final_time_relative_l2:.3e}, "
        f"validation MSE={validation_observation_mse:.3e}"
        if validation_observation_mse is not None
        else f"status={gif_status}, epochs={cfg.train.epochs}, final relative L2={pinn_final_time_relative_l2:.3e}"
    )
    gif_diagnostics = save_pinn_evolution_gif(
        cfg.out_dir / "pinn_evolution.gif",
        truth,
        best.model,
        cfg.domain,
        device,
        caption=gif_caption,
        warning=gif_warning,
    )
    gif_diagnostics["status"] = gif_status

    centers = np.array(ensemble_centers, dtype=np.float64)
    figure_paths = [str(cfg.out_dir / name) for name in generated_figure_names()]
    metrics: dict[str, object] = {
        "config": cfg.to_dict(),
        "truth_origin": [cfg.seed.center_x, cfg.seed.center_y],
        "ensemble_origin_mean": centers.mean(axis=0).tolist(),
        "ensemble_origin_std": centers.std(axis=0).tolist(),
        "best_origin": list(best.origin),
        "best_origin_error": best.origin_error,
        "final_time_relative_l2": pinn_final_time_relative_l2,
        "pinn_final_time_relative_l2": pinn_final_time_relative_l2,
        "pinn_final_time_max_abs_error": float(np.max(pinn_final_abs_error)),
        "pinn_final_time_mean_abs_error": float(np.mean(pinn_final_abs_error)),
        "pinn_final_time_p95_abs_error": float(np.quantile(pinn_final_abs_error, 0.95)),
        "rk4_final_time_relative_l2": rk4_final_time_relative_l2,
        "rk4_final_time_max_abs_error": float(np.max(rk4_final_abs_error)),
        "rk4_final_time_mean_abs_error": float(np.mean(rk4_final_abs_error)),
        "rk4_final_time_p95_abs_error": float(np.quantile(rk4_final_abs_error, 0.95)),
        "pinn_vs_rk4_final_relative_l2": pinn_vs_rk4_final_relative_l2,
        "front_area_005_mae": front_geometry.get("area_above_050_mae"),
        "front_area_010_mae": front_geometry.get("area_above_100_mae"),
        "active_front_area_mae": front_geometry.get("active_band_mae"),
        "front_mae_005": front_geometry.get("front_mae_050"),
        "front_mae_010": front_geometry.get("front_mae_100"),
        "hausdorff_005": front_geometry.get("hausdorff_050"),
        "hausdorff_010": front_geometry.get("hausdorff_100"),
        "front_speed_mae_010": front_geometry.get("front_speed_mae_010"),
        "mass_mae": front_geometry.get("mass_mae"),
        "train_observation_mse": train_observation_mse,
        "validation_observation_mse": validation_observation_mse,
        "rk4_train_observation_mse": rk4_train_observation_mse,
        "rk4_validation_observation_mse": rk4_validation_observation_mse,
        "rk4_runtime_sec": rk4_runtime_sec,
        "train_observation_count": int(len(train_observations.xyt)),
        "validation_observation_count": int(len(validation_observations.xyt)),
        "warm_start_mode": cfg.warm_start.mode,
        "training_checkpoint": {
            "resume_from_checkpoint": bool(cfg.train.resume_from_checkpoint),
            "checkpoint_every": int(cfg.train.training_checkpoint_every),
            "latest_paths": [
                str(_training_checkpoint_path(cfg, run.seed))
                for run in runs
            ],
        },
        "front_geometry": front_geometry,
        "pinn_evolution_gif": gif_diagnostics,
        "diagnostic_fields": str(diagnostic_fields_path),
        "figures": figure_paths,
        "runs": [
            {
                "seed": run.seed,
                "origin": list(run.origin),
                "origin_error": run.origin_error,
                "checkpoint_epoch": run.checkpoint_epoch,
                "checkpoint_score": run.checkpoint_score,
                "physics": run.physics,
                "history": run.history,
            }
            for run in runs
        ],
        "baselines": [
            {
                "name": result.name,
                "center": list(result.center) if result.center is not None else None,
                "error": result.error,
                "extra": result.extra,
            }
            for result in baseline_results
        ],
    }
    write_json(cfg.out_dir / "metrics.json", metrics)
    print(f"wrote {cfg.out_dir / 'metrics.json'}")
    for figure_path in figure_paths:
        print(f"wrote {figure_path}")
    return metrics
